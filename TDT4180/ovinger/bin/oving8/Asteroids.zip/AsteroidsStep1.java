package oving8;

import java.awt.Color;

public class AsteroidsStep1 extends Asteroids {

	public void init() {
		SpaceObject spaceObject1 = new SpaceObject();
		spaceObject1.addPolarEdge(50, 0);
		spaceObject1.addPolarEdge(50, 90);
		spaceObject1.addPolarEdge(50, 180);
		spaceObject1.addPolarEdge(50, 270);
		spaceObject1.move(50, 50);
		spaceObject1.setSpeed(1, 1);
		spaceObject1.setFilled(true);
		spaceObject1.setFillColor(Color.WHITE);
		addSpaceObject(spaceObject1);
		
		SpaceObject spaceObject2 = new SpaceObject();
		spaceObject2.addPolarEdge(10, 45);
		spaceObject2.addPolarEdge(10, 135);
		spaceObject2.addPolarEdge(10, 225);
		spaceObject2.addPolarEdge(10, 315);
		spaceObject2.move(80, 150);
		spaceObject2.setSpeed(1, 0);
		spaceObject2.setFilled(true);
		spaceObject2.setFillColor(Color.WHITE);
		addSpaceObject(spaceObject2);
		
		SpaceObject spaceObject3 = new SpaceObject();
		spaceObject3.addPolarEdge(50, 0);
		spaceObject3.addPolarEdge(50, 135);
		spaceObject3.addPolarEdge(50, 225);
		spaceObject3.move(50, 350);
		spaceObject3.setSpeed(1, -1);
		spaceObject3.setFilled(true);
		spaceObject3.setFillColor(Color.WHITE);
		addSpaceObject(spaceObject3);
	}
}
