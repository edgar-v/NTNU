--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: farm; Type: TABLE; Schema: public; Owner: pi; Tablespace: 
--

CREATE TABLE farm (
    latitude1 real,
    longitude1 real,
    latitude2 real,
    longitude2 real,
    farmer integer
);


ALTER TABLE public.farm OWNER TO pi;

--
-- Name: log; Type: TABLE; Schema: public; Owner: pi; Tablespace: 
--

CREATE TABLE log (
    farmer integer NOT NULL,
    message text,
    sheep integer,
    "timestamp" timestamp with time zone DEFAULT now(),
    alive boolean DEFAULT true NOT NULL,
    alarm boolean DEFAULT false NOT NULL,
    longitude real,
    latitude real
);


ALTER TABLE public.log OWNER TO pi;

--
-- Name: sheep; Type: TABLE; Schema: public; Owner: pi; Tablespace: 
--

CREATE TABLE sheep (
    id integer NOT NULL,
    longitude real DEFAULT 10.3933 NOT NULL,
    latitude real DEFAULT 63.4297 NOT NULL,
    name character varying,
    age date DEFAULT ('now'::text)::date,
    weight integer,
    alive boolean DEFAULT true NOT NULL,
    alarm boolean DEFAULT false NOT NULL,
    bonde integer NOT NULL,
    comment character varying
);


ALTER TABLE public.sheep OWNER TO pi;

--
-- Name: sheep_id_seq; Type: SEQUENCE; Schema: public; Owner: pi
--

CREATE SEQUENCE sheep_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sheep_id_seq OWNER TO pi;

--
-- Name: sheep_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pi
--

ALTER SEQUENCE sheep_id_seq OWNED BY sheep.id;


--
-- Name: test; Type: TABLE; Schema: public; Owner: pi; Tablespace: 
--

CREATE TABLE test (
    id integer NOT NULL
);


ALTER TABLE public.test OWNER TO pi;

--
-- Name: users; Type: TABLE; Schema: public; Owner: pi; Tablespace: 
--

CREATE TABLE users (
    id integer NOT NULL,
    username character varying,
    name character varying,
    email character varying,
    tlf character varying,
    password character varying,
    salt character varying,
    recovery character varying,
    secondary_email text,
    gcm text
);


ALTER TABLE public.users OWNER TO pi;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: pi
--

CREATE SEQUENCE users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO pi;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pi
--

ALTER SEQUENCE users_id_seq OWNED BY users.id;


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: pi
--

ALTER TABLE ONLY sheep ALTER COLUMN id SET DEFAULT nextval('sheep_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: pi
--

ALTER TABLE ONLY users ALTER COLUMN id SET DEFAULT nextval('users_id_seq'::regclass);


--
-- Name: uniqueusername; Type: CONSTRAINT; Schema: public; Owner: pi; Tablespace: 
--

ALTER TABLE ONLY users
    ADD CONSTRAINT uniqueusername UNIQUE (username);


--
-- Name: users_pkey; Type: CONSTRAINT; Schema: public; Owner: pi; Tablespace: 
--

ALTER TABLE ONLY users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- Name: users; Type: ACL; Schema: public; Owner: pi
--

REVOKE ALL ON TABLE users FROM PUBLIC;
REVOKE ALL ON TABLE users FROM pi;
GRANT ALL ON TABLE users TO pi;


--
-- Name: users_id_seq; Type: ACL; Schema: public; Owner: pi
--

REVOKE ALL ON SEQUENCE users_id_seq FROM PUBLIC;
REVOKE ALL ON SEQUENCE users_id_seq FROM pi;
GRANT ALL ON SEQUENCE users_id_seq TO pi;


--
-- PostgreSQL database dump complete
--

