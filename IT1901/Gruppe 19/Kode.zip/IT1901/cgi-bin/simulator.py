#!/usr/bin/python
# -*- coding: utf-8 -*-
import psycopg2
import random
import urllib2
import json
import smtplib
from email.mime.text import MIMEText

connection = None
cursor = None

def main(farmerid = None):
    global connection
    connection = psycopg2.connect("dbname=findmysheep user=postgres host=localhost password=kohxooto")
    global cursor
    cursor  = connection.cursor()
    update_all(farmerid)

def send_notification(users, sheep):
    if len(users) == 0:
        return
    # Google cloud messaging
    url = 'https://android.googleapis.com/gcm/send'
    headers = { 'Content-Type':'application/json',
                'Authorization':'key=AIzaSyD6WRduZVOHFgYrX-AGPZtNQW7RAjJWrcY' }
    gcmids = []
    for key, values in users.items():
        if users[key][9] != None:
            gcmids.append(users[key][9])
        deadsheep = []
        alarmsheep = []
        for i in sheep:
            if i[8] == users[key][0]:
                if i[6] == False:
                    deadsheep.append(i)
                if i[7] == True:
                    alarmsheep.append(i)
        msg = ""
        for i in deadsheep:
            msg += i[3] + ' er død.\n'
        for i in alarmsheep:
            msg += i[3] + ' er under angrep.\n'
        if msg == "":
            continue
        # Primary Email
        mail = MIMEText(msg)
        mail['Subject'] = 'Something terrible has happened'
        mail['From'] = 'findmysheep'
        mail['To'] = users[key][3]
        smtp = smtplib.SMTP('smtp.gmail.com:587')
        smtp.starttls()
        smtp.login('findmyherd@gmail.com', 'Supa!Boo8')
        smtp.sendmail('findmysheep', users[key][3], mail.as_string())

        # Secondary email
        if users[key][8] != None:
            smtp.sendmail('findmysheep', users[key][8], mail.as_string())
        smtp.quit()
    if len(deadsheep) == 0 and alarmsheep == 0:
        msg = "update"
    else:
        msg = "A sheep is under attack"
    data = json.dumps({'registration_ids':  gcmids , 'data' : {"msg":msg}}) 
    req = urllib2.Request(url, data, headers)
    response = urllib2.urlopen(req)

def create_random_coordinates(farmerid):
    connection = psycopg2.connect("dbname=findmysheep user=postgres host=localhost password=kohxooto")
    cursor = connection.cursor()
    cursor.execute("SELECT * FROM farm WHERE farmer = '%s';" % farmerid)
    coords = cursor.fetchone()
    longitude = coords[0] + (coords[2] - coords[0]) * (random.random() * 0.4)
    latitude = coords[1] + (coords[3] - coords[1]) * (random.random() * 0.4)
    return [longitude, latitude]
  

def update_all(farmerid = None):
    f = open('log.txt', 'w')
    f.write(str(farmerid))
    sheeps = [] 
    if farmerid != None:
        cursor.execute("SELECT * FROM sheep WHERE bonde = '%s' ORDER BY id;" % farmerid)
    else:
        cursor.execute("SELECT * FROM sheep ORDER BY id;")
    sheep = cursor.fetchall()
    f.write(str(sheep))
    cursor.execute("SELECT * FROM farm;")

    farms = cursor.fetchall()
    farmDict = {}
    users_with_sheep = {}
    for i in farms:
        farmDict[i[4]] = i

    for i in sheep:
        farmerId = i[8]
        if farmerId not in users_with_sheep:
            cursor.execute("SELECT * FROM users WHERE id = '%s';" % farmerId)
            val = cursor.fetchone()
            users_with_sheep[farmerId] = val
        
        # If the sheep is dead, do not do anything
        if i[6] == False:
            continue
        coords = farmDict[farmerId]
        latitude = coords[0] + (coords[2] - coords[0]) * (random.random() * 0.4)
        longitude = coords[1] + (coords[3] - coords[1]) * (random.random() * 0.4)
        alarm = False
        # 0,001% chance for a sheep to be instantly killed
        if (i[6] == True and random.randint(0, 200) == 1): 
            alive = False
            sheeps.append(i)
        elif i[7] == False and random.randint(0, 200) == 1:
            alarm = True
            sheeps.append(i)
        else:
            alive = True
            alarm = False
        cursor.execute("UPDATE sheep SET longitude = %.4f, latitude = %.4f, alive = %s, alarm = %s WHERE id = %s" % (latitude, longitude, alive, alarm,  i[0]))
        message = str(latitude) + "," + str(longitude) + ',' + str(alive) + ',' + str(alarm)
        cursor.execute("INSERT INTO log (farmer, sheep, message, alive, alarm, longitude, latitude) VALUES (%s, %s, '%s', '%s', '%s', '%s', '%s')" % (farmerId, i[0], message, alive, alarm, longitude, latitude))
    
    if len(users_with_sheep) == 0:
        return
    f.write("\n" + str(users_with_sheep))
    f.close()
    cursor.close()
    connection.commit()
    connection.close()
    if len(sheep) == 0:
        return
    send_notification(users_with_sheep, sheeps)
    
if __name__ == "__main__":
    main()
