#!/usr/bin/python

import psycopg2
import hashlib
import sys
import cgi
import random
import simulator

connection = psycopg2.connect("dbname=findmysheep user=postgres host=localhost password=kohxooto")
cur = connection.cursor()

form = cgi.FieldStorage()

try:
    username = form['username'].value
except KeyError:
    print '''Status: 400
Content-type: text/html

No user with that username exists
'''
    sys.exit()

# Check if the user exists
cur.execute("SELECT id from users WHERE username = '%s'" % username)
farmerid = cur.fetchone()
cur.close()
connection.close()

simulator.main(farmerid)

print '''Status: 200
Content-type: text/html

'''
