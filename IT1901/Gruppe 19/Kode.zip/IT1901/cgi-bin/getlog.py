#!/usr/bin/python

import psycopg2
import hashlib
import sys
import cgi
import random
import datetime

import cgitb
cgitb.enable()

connection = psycopg2.connect("dbname=findmysheep user=postgres host=localhost password=kohxooto")
cur = connection.cursor()

form = cgi.FieldStorage()

try:
    username = form['username'].value
    #username = "hannemtr"
except KeyError:
    print '''Status: 400
Content-type: text/html

No user with that username exists
'''
    sys.exit()

# Check if the user exists
cur.execute("SELECT id from users WHERE username = '%s'" % username)
row = cur.fetchone()
cur.execute("SELECT * from log WHERE farmer = '%s';" % row[0])
messages = cur.fetchall()
if messages  == None:
    print '''Status: 404
Content-type: text/html

'''
    sys.exit()

cur.close()
connection.close()

print '''Status: 200
Content-type: text/html

'''
for i in range(len(messages)):
    print("%s,%s,%s," % (messages[i][2], messages[i][1], str(messages[i][3] + datetime.timedelta(hours=1)).split('.')[0]))
