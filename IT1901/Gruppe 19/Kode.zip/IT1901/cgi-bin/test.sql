CREATE TABLE test (id integer not null);
