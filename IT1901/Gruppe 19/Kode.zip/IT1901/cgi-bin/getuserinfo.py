#!/usr/bin/python

import psycopg2
import hashlib
import sys
import cgi
import random

#For debugging
import cgitb
cgitb.enable()


connection = psycopg2.connect("dbname=findmysheep user=postgres host=localhost password=kohxooto")
cur = connection.cursor()

form = cgi.FieldStorage()

try:
    username = form['username'].value
except KeyError:
    print '''Status: 400
Content-type: text/html

No user with that username exists
'''
    sys.exit()

# Check if the user exists
cur.execute("SELECT * FROM users WHERE username = '%s';" % username)
row = cur.fetchone()
if row  == None:
    print '''Status: 404
Content-type: text/html

'''
    sys.exit()

connection.commit()
cur.close()
connection.close()

print '''Status: 200
Content-type: text/html

'''
output = row[1] + ',' + row[2] + ',' + row[3] + ',' + row[4]
if row[8] != None:
    output += ',' + row[8]
print(output)

