#!/usr/bin/python

import psycopg2
import hashlib
import random
import cgi
import sys

#for debugging
import cgitb
cgitb.enable()

# Establish a connection to the database
conn = psycopg2.connect("dbname=findmysheep user=postgres host=localhost password=kohxooto")

# Fetch parameters from the request
form = cgi.FieldStorage()

# See if the parameters were sent
try:
    secondary = form['backup'].value
except KeyError, e:
    secondary = None

try:
    username = form['username'].value
    email = form['email'].value
    name = form['name'].value
    tlf = form['tlf'].value
except KeyError, e:
    print '''Status: 400
Content-type: text/html

'''
    print("missing argument")
    print e
    sys.exit()


# If no password, continue, but do not change password in db.
try:
    password = form['password'].value
    oldpass = form['oldpassword'].value
except KeyError, e:
    password = ''
    oldpass = ''

cur = conn.cursor()

cur.execute("SELECT * FROM users where username = '%s';" % username)

row = cur.fetchone()
if row == None:
    print '''Status: 400
Content-type: text/html

'''
    print "User does not exist"
    sys.exit()
# If the password is not set it means we should not change it
if password == '':
    if secondary != None:
        sql = "UPDATE users SET email = '%s', name = '%s', tlf = '%s' WHERE username = '%s';" % (email, name, tlf, username)
    else:
        sql = "UPDATE users SET email = '%s', name = '%s', tlf = '%s', secondary_email = '%s' WHERE username = '%s';" % (email, name, tlf, secondary, username)
    try:
        cur.execute(sql)
    except Exception:
        print '''Status: 420
Content-type: text/html

'''
        sys.exit()
  
else:
    original_password = row[5]
    salt = row[6]
    password_hash = hashlib.sha1(bytes(oldpass + salt)).hexdigest()

    if password_hash != original_password:
        print '''Status: 400
    Content-type: text/html

    '''
        print "wrong password"
        sys.exit()

    password_hash = hashlib.sha1(bytes(password + salt)).hexdigest()

    if secondary == None:
       sql = "UPDATE users SET email = '%s', name = '%s', tlf = '%s', password = '%s' WHERE username = '%s';" % (email, name, tlf, password_hash, username)
    else:
        sql = "UPDATE users SET email = '%s', name = '%s', tlf = '%s', password = '%s', secondary_email = '%s' WHERE username = '%s';" % (email, name, tlf, password_hash, secondary, username)
    try:
        # Insert the user into the database
        cur.execute(sql)
    except Exception:
        # If the transaction fails return an error and exit.
        # This will happen if the user already exists in the database
        print '''Status: 420
    Content-type: text/html

    '''
        sys.exit()

# Commit the changes we have made to the database
conn.commit()

# Close the connection
cur.close()
conn.close()

# Return an OK status message
print '''Status: 200
Content-type: text/html

'''

