#!/usr/bin/python

import psycopg2
import hashlib
import sys
import cgi
import json
from datetime import date

connection = psycopg2.connect("dbname=findmysheep user=postgres host=localhost password=kohxooto")
cursor = connection.cursor()

form = cgi.FieldStorage()

try:
    username = form['username'].value
except KeyError:
    print '''Status: 400
Content-type: text/html

No user with that username exists
'''
    sys.exit()

# Check if the user exists
cursor.execute("SELECT id from users WHERE username = '%s'" % username)
user_id = cursor.fetchone()

print '''Status: 200
Content-type: text/html

'''

cursor.execute("SELECT * FROM sheep WHERE bonde = %s ORDER BY id;" % user_id)
sheep = cursor.fetchall()

sheepjson = []
for s in sheep:
    sheepdict = {'id':s[0],'longitude':s[1], 'latitude':s[2], 'name':s[3],     'age':str(s[4]), 'weight':s[5], 'alive':s[6], 'alarm':s[7], 'comment':s[9]}
    sheepjson.append(sheepdict)

cursor.execute("SELECT * from log WHERE farmer = %s;" % user_id)

log = cursor.fetchall()

logjson = []
for l in log:
    logdict = {'sheep': l[2], 'timestamp':str(l[3]), 'alive':l[4], 'alarm':    l[5], 'longitude':l[6], 'latitude':l[7]}
    logjson.append(logdict)

jsondata = { "sheep" : sheepjson, "log" : logjson }
jsondata = json.dumps(jsondata)
response = jsondata
print(response)

cursor.close()
connection.close()
