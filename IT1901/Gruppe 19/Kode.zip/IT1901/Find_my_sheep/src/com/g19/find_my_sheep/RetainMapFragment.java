package com.g19.find_my_sheep;

import android.os.Bundle;
import com.google.android.gms.maps.MapFragment;

/**
<<<<<<< HEAD
 * @author Fredrik Borgen T�rnvall 
 * Denne klassen setter RetainInstance til true p� MapFragment. For at kartet ikke skal tegnes inn n�r det allerede finnes.  
=======
 * @author Fredrik Borgen Tørnvall
 *
>>>>>>> origin/Javadoc-HM
 */
public class RetainMapFragment extends MapFragment{
	
	@Override
	 public void onActivityCreated(Bundle savedInstanceState) {
	  super.onActivityCreated(savedInstanceState);
	  setRetainInstance(true);
	 }

}
