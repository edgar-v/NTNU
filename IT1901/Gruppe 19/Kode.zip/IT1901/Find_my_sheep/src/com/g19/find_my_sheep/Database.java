package com.g19.find_my_sheep;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

/**
 * Intern database som inneholder informasjon om sauer og logg for hver sau
 * @author Edgar Vedvik
 * @author Hanne Marie Trelease
 */
public class Database extends SQLiteOpenHelper {
	public static final String TABLE_SHEEP = "sheep";
	public static final String TABLE_LOG = "log";

	private static final String DATABASE_NAME = "sheepDatabase";
	public static int DATABASE_VERSION = 3;

	private static final String DATABASE_CREATE = "CREATE TABLE " + TABLE_SHEEP +
			" (id integer primary key autoincrement, longitude real not null, " +
			"latitude real not null, name text not null, weight integer not null, " +
			"age text not null, alive boolean default true, alarm boolean default false, " +
			"health text); ";
	
	private static final String LOG_CREATE = "create table " + TABLE_LOG + " (time text," +
			" longitude real not null, latitude real not null, alive text," +
			" alarm text, sheepId integer not null);";

	public Database(Context context) {
		super(context, DATABASE_NAME, null, DATABASE_VERSION);
	}

	@Override
	public void onCreate(SQLiteDatabase database) {
		database.execSQL(DATABASE_CREATE);
		database.execSQL(LOG_CREATE);
	}


	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
		Log.w(Database.class.getName(),
				"Upgrading database from version " + oldVersion + " to "
						+ newVersion + ", which will destroy all old data");
		db.execSQL("DROP TABLE IF EXISTS " + TABLE_SHEEP);
		db.execSQL("DROP TABLE IF EXISTS " + TABLE_LOG);
		onCreate(db);
	}

	@Override
	public void onDowngrade(SQLiteDatabase db, int oldVersion, int newVersion) {
		onUpgrade(db, oldVersion, newVersion);
	}

	@Override
	public void onOpen(SQLiteDatabase db) {
		super.onOpen(db);
	}

	
	/**
	 * Sletter all informasjon i databasen
	 * @param db
	 */
	public void delete(SQLiteDatabase db) {
		Log.w(Database.class.getName(),
				"Deleting database, which will destroy all old data");
		db.execSQL("DROP TABLE IF EXISTS " + TABLE_SHEEP);
		db.execSQL("DROP TABLE IF EXISTS " + TABLE_LOG);
		onCreate(db);
	}
	
} 