package com.g19.find_my_sheep;


import java.util.ArrayList;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

/**
 * @author Fredrik Borgen Tørnvall
 *
 */

public class UserMenu extends Activity{
	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		getUserInfo();
	}

	DatabaseSuperpower sheepNum;
	ArrayList<Integer> idlist = new ArrayList<Integer>();
	
	@Override
	public void onCreate(Bundle bundle) {
		super.onCreate(bundle);
		setContentView(R.layout.user_menu);
		getUserInfo();
	}
	
	public void getUserInfo(){
		sheepNum = new DatabaseSuperpower(UserMenu.this);
		sheepNum.open();
		
		Button edit = (Button) findViewById(R.id.b6edituser);
		
		edit.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				Intent intent = new Intent(UserMenu.this, EditUser.class);
				startActivity(intent);
			}
		});
		
		final TextView username = (TextView) findViewById(R.id.etUser);
		username.setText(LogginStatus.getUserName(UserMenu.this));
		final TextView name = (TextView) findViewById(R.id.etName);
		name.setText(LogginStatus.getName(UserMenu.this));
		final TextView email = (TextView) findViewById(R.id.etEmail);
		email.setText(LogginStatus.getEmail(UserMenu.this));
		final TextView password = (TextView) findViewById(R.id.etPassword);
		password.setText("*********");
		final TextView telephone = (TextView) findViewById(R.id.etTlf);
		telephone.setText(LogginStatus.getTlf(UserMenu.this));
		final TextView etbackup = (TextView) findViewById(R.id.etbackup);
		etbackup.setText(LogginStatus.getBackup(UserMenu.this));
		
		
		final TextView etSheepNum = (TextView) findViewById(R.id.etSheepNum);
		idlist = sheepNum.getSheepIdFromDatabase();
		etSheepNum.setText(Integer.toString(idlist.size()));
		sheepNum.close();
		
	}
}