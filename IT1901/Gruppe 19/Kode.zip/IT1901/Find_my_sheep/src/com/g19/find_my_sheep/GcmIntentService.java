package com.g19.find_my_sheep;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

import com.google.android.gms.gcm.GoogleCloudMessaging;

import android.app.IntentService;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.SystemClock;
import android.support.v4.app.NotificationCompat;
import android.support.v4.content.WakefulBroadcastReceiver;
import android.util.Log;
import android.widget.EditText;
import android.widget.TextView;

/**
 * @author Edgar Vedvik
 *
 */

/**
 * Klasse som tar i mot en melding fra Google Cloud Messaging og prosesserer den.
 * @author Edgar Vedvik
 *
 */
public class GcmIntentService extends IntentService {
	public static final int NOTIFICATION_ID = 1;
    private NotificationManager mNotificationManager;
    NotificationCompat.Builder builder;

    public GcmIntentService() {
        super("GcmIntentService");
    }

    /**
     * Leser meldingen og oppdaterer dataene i bakgrunnen om det er en ny oppdatering eller så lager den en notifikasjon om en sau
     * er under angrep eller har dødd.
     */
    @Override
    protected void onHandleIntent(Intent intent) {
        Bundle extras = intent.getExtras();
        GoogleCloudMessaging gcm = GoogleCloudMessaging.getInstance(this);
        // The getMessageType() intent parameter must be the intent you received
        // in your BroadcastReceiver.
        String messageType = gcm.getMessageType(intent);

        if (!extras.isEmpty()) {  // has effect of unparcelling Bundle
            /*
             * Filter messages based on message type. Since it is likely that GCM
             * will be extended in the future with new message types, just ignore
             * any message types you're not interested in, or that you don't
             * recognize.
             */
            if (GoogleCloudMessaging.
                    MESSAGE_TYPE_SEND_ERROR.equals(messageType)) {
                sendNotification("Send error: " + extras.toString());
            } else if (GoogleCloudMessaging.
                    MESSAGE_TYPE_DELETED.equals(messageType)) {
                sendNotification("Deleted messages on server: " +
                        extras.toString());
            // If it's a regular GCM message, do some work.
            } else if (GoogleCloudMessaging.
                    MESSAGE_TYPE_MESSAGE.equals(messageType)) {
                // This loop represents the service doing some work.
                
                Log.i("GCM", "Completed work @ " + SystemClock.elapsedRealtime());
                // Post notification of received message.
                String msg = extras.toString();
                msg = msg.substring(msg.indexOf("=") + 1,msg.indexOf(","));
                if (msg == "update")
                {
                	System.out.println("updating");
                	new updateAction().execute();
                	return;
                }
                sendNotification(msg);
                Log.i("GCM", msg);
            }
        }
        // Release the wake lock provided by the WakefulBroadcastReceiver.
        WakefulBroadcastReceiver.completeWakefulIntent(intent);
    }
    
    /**
     * 
     * Starter en ny asynkron jobb med intensjon om å hente ny data fra server for så å lagre den lokalt.
     * @author Edgar Vedvik
     *
     */
    private class updateAction extends AsyncTask<Void,Void,Boolean>{

		@Override
		protected void onPostExecute(Boolean result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);		
		}

		@Override
		protected Boolean doInBackground(Void... params) {
			// TODO Auto-generated method stub
			return update();
		}
	}

    /**
     * Kaller endepunktet på serveren som henter nye posisjoner, status og logg.
     * Informasjonen blir gitt videre til to hjelpemetodene storeSheepInfo og storeLogInfo.
     * @return Boolean
     */
	private Boolean update(){
		// Create a new HttpClient and Post Header
		HttpClient httpclient = new DefaultHttpClient();
		HttpPost httppost = new HttpPost("http://129.241.126.66/cgi-bin/update.py");


		try {
			// Add your data
			List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(2);
			nameValuePairs.add(new BasicNameValuePair("username", LogginStatus.getUserName(GcmIntentService.this)));
			httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));

			// Execute HTTP Post Request
			ResponseHandler<String> responseHandler = new BasicResponseHandler();
			String response = httpclient.execute(httppost, responseHandler);


			//Om responsen fra server er 200 (OK), lagres brukernavnet i appen, til senere bruk. 
			if(response != null){
				JSONObject object = (JSONObject) new JSONTokener(response).nextValue();
				JSONArray sheepjson = object.getJSONArray("sheep");
				JSONArray logjson = object.getJSONArray("log");
				
				storeSheepInfo(sheepjson);
				storeLogInfo(logjson);
				
				return true;
			}
		} catch (ClientProtocolException e) {
			// TODO Auto-generated catch block
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return false;
	}
	
	/**
	 * Tar inn JSON data om sauer og putter det inn i den lokale databasen.
	 * @param json en JSONArray
	 */
	private void storeSheepInfo(JSONArray json)
	{
		DatabaseSuperpower source = new DatabaseSuperpower(GcmIntentService.this);
		source.open();
		ContentValues sheep = new ContentValues();
		try 
		{
			
			for (int i = 0; i < json.length(); i++) {
				JSONObject sheepJson = json.getJSONObject(i);
				sheep.put("id", sheepJson.getInt("id"));
				sheep.put("longitude", sheepJson.getDouble("longitude"));
				sheep.put("latitude", sheepJson.getDouble("latitude"));
				sheep.put("name", sheepJson.getString("name"));
				sheep.put("age", sheepJson.getString("age"));
				sheep.put("weight", sheepJson.getInt("weight"));
				sheep.put("alive", sheepJson.getBoolean("alive"));
				sheep.put("alarm", sheepJson.getBoolean("alarm"));
				if (sheepJson.has("comment")) 
				{
					sheep.put("health", sheepJson.getString("comment"));
				}
				source.startUp(sheep);
			} 
		}	
		catch (JSONException e) 
		{
				System.out.println(e.getMessage());
		}
		finally
		{
			source.close();
		}
			
	}
	
	/**
	 * Hjelpermetode for å putte jsondata om logg inn i den lokale databasen. 
	 * @param json en JSONArray
	 */
	private void storeLogInfo(JSONArray json)
	{
		DatabaseSuperpower source = new DatabaseSuperpower(GcmIntentService.this);
		source.open();
		System.out.println(json.toString());
		ContentValues values = new ContentValues();
		try {
			for (int i = 0; i < json.length(); i++)
			{
				JSONObject logjson = json.getJSONObject(i);
				System.out.println(logjson.getDouble("longitude"));
				System.out.println(logjson.getDouble("latitude"));
				values.put("sheepId", logjson.getInt("sheep"));
				values.put("longitude", logjson.getDouble("longitude"));
				values.put("latitude", logjson.getDouble("latitude"));
				values.put("alive", logjson.getString("alive"));
				values.put("alarm", logjson.getString("alarm"));
				values.put("time", logjson.getString("timestamp"));
				source.logAdd(values);
			}
		} 
		catch (JSONException e)
		{
			System.out.println(e.getMessage());
		}
		finally 
		{
			source.close();
		}
	}

    // Put the message into a notification and post it.
    // This is just one simple example of what you might choose to do with
    // a GCM message.
	
    /**
     * Metode som sender ut en notifikasjon om at en sau er under angrep / har dødd.
     * @param msg
     */
    private void sendNotification(String msg) {
        mNotificationManager = (NotificationManager)
                this.getSystemService(Context.NOTIFICATION_SERVICE);

        PendingIntent contentIntent = PendingIntent.getActivity(this, 0,
                new Intent(this, Map.class), 0);

        NotificationCompat.Builder mBuilder =
                new NotificationCompat.Builder(this)
        .setSmallIcon(R.drawable.ic_launcher)
        .setContentTitle(msg)
        .setStyle(new NotificationCompat.BigTextStyle()
        .bigText(msg))
        .setDefaults(Notification.DEFAULT_ALL)
        .setAutoCancel(true)
        .setContentText("Trykk her for å åpne kartet");
        mBuilder.setContentIntent(contentIntent);
        Notification notification = mBuilder.build();
        notification.flags |= Notification.PRIORITY_HIGH;
        notification.defaults |= Notification.DEFAULT_VIBRATE;
        notification.defaults |= Notification.FLAG_AUTO_CANCEL;
        
        mNotificationManager.notify(NOTIFICATION_ID, notification);
    }
}

