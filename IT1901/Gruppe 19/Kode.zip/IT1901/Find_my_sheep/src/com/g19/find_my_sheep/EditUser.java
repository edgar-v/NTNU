package com.g19.find_my_sheep;


import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;

import android.app.Activity;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

/**
 * @author Fredrik Borgen T�rnvall
 * 
 * Denne klassen gir brukeren mulighet til � endre opplysningene lagret i profilen.
 */
public class EditUser extends Activity{

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_edituser);
		Button reg = (Button) findViewById(R.id.b6edituser);
		getActionBar().setDisplayHomeAsUpEnabled(true);

		final TextView username = (TextView) findViewById(R.id.etUser);
		username.setText(LogginStatus.getUserName(EditUser.this));
		final EditText name = (EditText) findViewById(R.id.etName);
		name.setText(LogginStatus.getName(EditUser.this));
		final EditText email = (EditText) findViewById(R.id.etEmail);
		email.setText(LogginStatus.getEmail(EditUser.this));
		final EditText telephone = (EditText) findViewById(R.id.etTlf);
		telephone.setText(LogginStatus.getTlf(EditUser.this));
		
		final EditText resPass = (EditText) findViewById(R.id.etBack);
		resPass.setText(LogginStatus.getBackup(EditUser.this));

		reg.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View arg0) {
				new editAction().execute();
			}

		});
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case android.R.id.home:
			this.finish();

			return true;
		}
		return super.onOptionsItemSelected(item);
	}

	private class editAction extends AsyncTask<Void,Void,Integer>{




		@Override
		protected void onPostExecute(Integer result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			if(result == 200){
				finish();
			}
		}


		@Override
		protected Integer doInBackground(Void... params) {
			// TODO Auto-generated method stub
			return edit();
		}


		
		/**
		 * @return databaserespons Returnerer 200 om opplysningene som er endret blir lagret i databasen 
		 */
		private int edit(){
			HttpClient httpclient = new DefaultHttpClient();
			HttpPost httppost = new HttpPost("http://129.241.126.66/cgi-bin/edituser.py");

			final EditText name = (EditText) findViewById(R.id.etName);
			final EditText email = (EditText) findViewById(R.id.etEmail);
			final TextView username = (TextView) findViewById(R.id.etUser);
			final EditText password = (EditText) findViewById(R.id.etPassword);
			final EditText telephone = (EditText) findViewById(R.id.etTlf);
			final EditText oldPassword = (EditText) findViewById(R.id.etOldPass);
			final EditText backup = (EditText) findViewById(R.id.etBack);

			String nameString = name.getText().toString();
			String emailString = email.getText().toString();
			String usernameString = username.getText().toString();
			String passwordString = password.getText().toString();
			String telephoneString = telephone.getText().toString();
			String oldPasswordString = oldPassword.getText().toString();
			String backupString = backup.getText().toString();
			
			/** Sender alle parameterne som kan endres til skriptet som oppdaterer databasen */
			try {
				// Add your data
				List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(7);
				nameValuePairs.add(new BasicNameValuePair("name", nameString));
				nameValuePairs.add(new BasicNameValuePair("email", emailString));
				nameValuePairs.add(new BasicNameValuePair("username", usernameString));
				nameValuePairs.add(new BasicNameValuePair("password", passwordString));
				nameValuePairs.add(new BasicNameValuePair("tlf", telephoneString));
				nameValuePairs.add(new BasicNameValuePair("oldpassword", oldPasswordString));
				nameValuePairs.add(new BasicNameValuePair("backup", backupString));

				httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));

				// Execute HTTP Post Request
				HttpResponse response = httpclient.execute(httppost);
				
				if(response.getStatusLine().getStatusCode() == 200){
					LogginStatus.setName(EditUser.this, nameString);
					LogginStatus.setEmail(EditUser.this, emailString);
					LogginStatus.setPass(EditUser.this, passwordString);
					LogginStatus.setTlf(EditUser.this, telephoneString);
					LogginStatus.setBackup(EditUser.this, backupString);
				}
				return response.getStatusLine().getStatusCode();

			} catch (ClientProtocolException e) {
				// TODO Auto-generated catch block
			} catch (IOException e) {
				// TODO Auto-generated catch block
			} catch(Exception e){
				e.printStackTrace();
			}
			return 0;
		}

	}
}

