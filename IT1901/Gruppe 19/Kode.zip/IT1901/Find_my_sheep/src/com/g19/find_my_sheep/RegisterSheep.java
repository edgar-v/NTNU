package com.g19.find_my_sheep;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.apache.http.HeaderElement;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.utils.URLEncodedUtils;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.protocol.HTTP;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.DialogFragment;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.ParseException;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Klasse som håndterer registrering av sauer
 * @author Hanne Marie Trelease
 */
public class RegisterSheep extends Activity {
	DatabaseSuperpower source;
	static int year;
	static int month;
	static int day;
	static EditText birthday;
	Button regSheep;

	@Override
	protected void onCreate(Bundle savedInstanceState){
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_sheep_reg);
		source= new DatabaseSuperpower(RegisterSheep.this);
		source.open();
		
		regSheep = (Button) findViewById(R.id.b3sheepReg);
		
		birthday = (EditText) findViewById(R.id.etSheepAge);
		birthday.setOnTouchListener(new OnTouchListener() {
			
			@Override
			public boolean onTouch(View v, MotionEvent event) {
		        if (event.getAction() == MotionEvent.ACTION_UP) {
		            showDatePickerDialog(v);
		        }
		        return false;
			}
		});

		regSheep.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				if(isNetworkAvailable()){
					new RegSheepAction().execute();
					regSheep.setEnabled(false);
				}else
					Toast.makeText(RegisterSheep.this, "Ingen nettverkstilkobling", Toast.LENGTH_SHORT).show();

			}
		});

	}

	/** @see EditSheep#showDatePickerDialog(View)*/
	public void showDatePickerDialog(View v) {
		DialogFragment newFragment = new DatePickerFragment();
		newFragment.show(getFragmentManager(), "datePicker");
	}

	/** @see MainActivity#isNetworkAvailable() */
	private boolean isNetworkAvailable() {
		ConnectivityManager connectivityManager 
		= (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
		NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
		return activeNetworkInfo != null && activeNetworkInfo.isConnected();
	}

    @Override
    public void onBackPressed() {
        //super.onBackPressed();
        if(regSheep.isEnabled()){
            super.onBackPressed();
        } else{
        	Toast.makeText(RegisterSheep.this, "Vent", Toast.LENGTH_SHORT).show();
        }
    }

    /** Trådklasse som håndterer saueregistreringsprosessen.
     * Avslutter aktiviteten dersom responsen fra databasen er 200 (OK) og åpner saueliste
     */
	private class RegSheepAction extends AsyncTask<Void,Void,Integer>{

		@Override
		protected void onPostExecute(Integer result) {
			super.onPostExecute(result);

			TextView display = (TextView) findViewById(R.id.tvsheepLog);
			display.setText(Integer.toString(result));

			if(result == 200){
				new Handler().postDelayed(new Runnable() {
					@SuppressLint("NewApi")
					@Override
					public void run() {
						Intent intent = getParentActivityIntent();
						intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
						startActivity(intent);
						finish();
					}
				}, 0);
			}else{
				regSheep.setEnabled(false);
			}
		}

		@Override
		protected Integer doInBackground(Void... params) {
			return reg();

		}

		/**
		 * Metode som legger informasjonen om en sau inn i databasene
		 * @return databaserespons	returnerer respons fra databasen
		 */
		private int reg(){

			HttpClient httpclient = new DefaultHttpClient();
			HttpPost httppost = new HttpPost("http://129.241.126.66/cgi-bin/regsheep.py");

			final EditText name = (EditText) findViewById(R.id.etSheepName);
			final EditText weight = (EditText) findViewById(R.id.etSheepWeight);
			final EditText health = (EditText) findViewById(R.id.etSheepHealth);



			String username = LogginStatus.getUserName(RegisterSheep.this);
			String nameString = name.getText().toString();
			String ageString = year + "-" + month + "-" + day;
			String weightString = weight.getText().toString();
			String healthString = health.getText().toString();

			/* Sender med informasjon om sau som parameter til "regsheep.py" og lagrer informasjon om sau i databasen */
			try {
				// Add your data
				List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(5);
				nameValuePairs.add(new BasicNameValuePair("username", username));
				nameValuePairs.add(new BasicNameValuePair("name", nameString));
				nameValuePairs.add(new BasicNameValuePair("age", ageString));
				nameValuePairs.add(new BasicNameValuePair("weight", weightString));
				nameValuePairs.add(new BasicNameValuePair("health", healthString));
				String values = URLEncodedUtils.format(nameValuePairs, HTTP.UTF_8);
				StringEntity entity = new StringEntity(values, HTTP.UTF_8);
				entity.setContentType(URLEncodedUtils.CONTENT_TYPE);
				httppost.setEntity(entity);

				// Execute HTTP Post Request
				HttpResponse response = httpclient.execute(httppost);
				String responseBody = getResponseBody(response);
				String[] latlng = responseBody.trim().split(",");
				
				/* Hvis sauen blir lagret som den skal i databasen sendes det tilbake informasjon om sauen og sauens id som
				 * som legges til i den lokale databasen */
				if(response.getStatusLine().getStatusCode() == 200){
					nameValuePairs.add(new BasicNameValuePair("latitude", latlng[1]));
					nameValuePairs.add(new BasicNameValuePair("longitude", latlng[0]));
					nameValuePairs.add(new BasicNameValuePair("id", latlng[2]));
					source.sheepAdd(nameValuePairs);
					
				}
				source.close();


				return response.getStatusLine().getStatusCode();

			} catch(Exception e){
				e.printStackTrace();
			}
			source.close();
			return 0;
		}
	}
	
	/** @see EditSheep.DatePickerFragment */
	public static class DatePickerFragment extends DialogFragment
		implements DatePickerDialog.OnDateSetListener {

		@Override
		public Dialog onCreateDialog(Bundle savedInstanceState) {
			// Use the current date as the default date in the picker
			final Calendar c = Calendar.getInstance();
			int year = c.get(Calendar.YEAR);
			int month = c.get(Calendar.MONTH);
			int day = c.get(Calendar.DAY_OF_MONTH);


			// Create a new instance of DatePickerDialog and return it
			return new DatePickerDialog(getActivity(), this, year, month, day);
		}

		@Override
		public void onDateSet(DatePicker view, int y, int m, int d) {
			year = y;
			month = m+1;
			day = d;
			birthday.setText(day+"."+month+"."+year);

		}
	}
	
	
	/**
	 * Metode som håndterer informasjonen HTTPPost scriptet returnerer
	 * @param response  Informasjon fra database
	 * @return tekst
	 */
	public String getResponseBody(HttpResponse response) {

		String response_text = null;
		HttpEntity entity = null;
		try {
			entity = response.getEntity();
			response_text = _getResponseBody(entity);
		} catch (ParseException e) {
			e.printStackTrace();
		} catch (IOException e) {
			if (entity != null) {
				try {
					entity.consumeContent();
				} catch (IOException e1) {
				}
			}
		}
		return response_text;
	}

	/**
	 * Metode som håndterer informasjonen HTTPPost scriptet returnerer
	 * @param entity
	 * @return tekst
	 * @throws IOException
	 * @throws ParseException
	 */
	public String _getResponseBody(final HttpEntity entity) throws IOException, ParseException {

		if (entity == null) {
			throw new IllegalArgumentException("HTTP entity may not be null");
		}

		InputStream instream = entity.getContent();

		if (instream == null) return "";

		if (entity.getContentLength() > Integer.MAX_VALUE) {
			throw new IllegalArgumentException(
					"HTTP entity too large to be buffered in memory");
		}

		String charset = getContentCharSet(entity);

		if (charset == null) charset = HTTP.DEFAULT_CONTENT_CHARSET;

		Reader reader = new InputStreamReader(instream, charset);
		StringBuilder buffer = new StringBuilder();

		try {
			char[] tmp = new char[1024];
			int l;
			while ((l = reader.read(tmp)) != -1) {
				buffer.append(tmp, 0, l);
			}
		} finally {
			reader.close();
		}

		return buffer.toString();
	}


	/** 
	 * Metode som håndterer informasjonen HTTPPost scriptet returnerer
	 * @param entity
	 * @return charset
	 * @throws ParseException
	 */
	public String getContentCharSet(final HttpEntity entity) throws ParseException {
		if (entity == null) {
			throw new IllegalArgumentException("HTTP entity may not be null");
		}

		String charset = null;

		if (entity.getContentType() != null) {
			HeaderElement values[] = entity.getContentType().getElements();
			if (values.length > 0) {
				NameValuePair param = values[0].getParameterByName("charset");
				if (param != null) {
					charset = param.getValue();
				}
			}
		}
		return charset;
	}
}