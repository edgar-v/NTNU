package com.g19.find_my_sheep;


import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HeaderElement;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.protocol.HTTP;

import android.app.AlertDialog;
import android.app.ListActivity;
import android.app.ProgressDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.ParseException;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.ContextMenu;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.AdapterContextMenuInfo;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Klasse som viser en liste over alle sauer og har mulighet for å vise logg, legge til ny sau og oppdatere saueinformasjon og logg
 * @author Hanne Marie Trelease
 * @author Jim Tørlen
 */

public class SheepMenu extends ListActivity {
	public ArrayList<Integer> sheepId;
	public ArrayList<String> sheepNames;
	DatabaseSuperpower database;
	Button refreshList;
	ArrayAdapter<String> adapter;
	ProgressDialog progress;

	@Override
	public void onCreate(Bundle savedInstanceState){
		super.onCreate(savedInstanceState);
		setContentView(R.layout.sheep_menu);
		getActionBar().setDisplayHomeAsUpEnabled(true);

		database = new DatabaseSuperpower(SheepMenu.this);
		database.open();
		sheepNames = database.getSheepNamesFromDatabase();
		sheepId = database.getSheepIdFromDatabase();


		EditText inputSearch = (EditText) findViewById(R.id.inputSearch);
		inputSearch.setFocusable(true);
		inputSearch.setFocusableInTouchMode(true);

		if(sheepNames.size() > 0){
			TextView display = (TextView) findViewById(R.id.tvData);
			display.setVisibility(4);
		}

		adapter = new ArrayAdapter<String>(SheepMenu.this,
				android.R.layout.simple_list_item_1, sheepNames);
		setListAdapter(adapter);
		registerForContextMenu(getListView());
		inputSearch.addTextChangedListener(new TextWatcher() {
			/** Oppdaterer lista slik at bare det som søkes på blir vist */
			@Override
			public void onTextChanged(CharSequence cs, int start, int count, int after) {
				// When user changed the Text
				adapter.getFilter().filter(cs);
			}

			@Override
			public void beforeTextChanged(CharSequence cs, int start, int count, int after) {
				// TODO Auto-generated method stub

			}

			@Override
			public void afterTextChanged(Editable s) {
				// TODO Auto-generated method stub
			}
		});

		Button newSheep = (Button) findViewById(R.id.b3newSheep);
		newSheep.setOnClickListener(new View.OnClickListener() {

			/** Starter registrer sau-aktivitet */
			@Override
			public void onClick(View v) {
				Intent intent = new Intent(SheepMenu.this, RegisterSheep.class);
				startActivity(intent);
			}
		});

		Button sheepLog = (Button) findViewById(R.id.b3allSheepLog);
		sheepLog.setOnClickListener(new View.OnClickListener() {

			/** Starter logg-aktivitet */
			@Override
			public void onClick(View v) {
				Intent intent = new Intent(SheepMenu.this, Log.class);
				startActivity(intent);

			}
		});

		refreshList = (Button) findViewById(R.id.b3refresh);
		refreshList.setOnClickListener(new View.OnClickListener() {  
			
			/** Tvinger oppdatering fra simulatoren og oppdaterer informasjon om sauer og logg */
			@Override
			public void onClick(View v) { 
				if(isNetworkAvailable()){
					progress = new ProgressDialog(SheepMenu.this, AlertDialog.THEME_HOLO_DARK);
					progress.setTitle("Oppdaterer");
					progress.setMessage("Laster inn...");
					progress.show();

					new LogUpdate().execute();
				}else
					Toast.makeText(SheepMenu.this, "Ingen nettverkstilkobling", Toast.LENGTH_LONG).show();
			}
		});
	}


	@Override
	public void onCreateContextMenu(ContextMenu menu, View v,
			ContextMenuInfo menuInfo) {
		super.onCreateContextMenu(menu, v, menuInfo);
		MenuInflater inflater = getMenuInflater();
		inflater.inflate(R.menu.popup_menu, menu);
	}

	/** @see MainActivity#isNetworkAvailable() */
	private boolean isNetworkAvailable() {
		ConnectivityManager connectivityManager 
		= (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
		NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
		return activeNetworkInfo != null && activeNetworkInfo.isConnected();
	}

	@Override
	public boolean onContextItemSelected(MenuItem item) {
		AdapterContextMenuInfo info = (AdapterContextMenuInfo) item.getMenuInfo();

		@SuppressWarnings("unchecked")
		String name = (String) ((AdapterView<ListAdapter>) info.targetView.getParent())
				.getItemAtPosition(info.position);
		switch (item.getItemId()) {
		/* Åpner kartaktivitet og viser posisjon for en enkelt sau */
		case R.id.showSheepPos:
			Intent intent = new Intent(SheepMenu.this, Map.class);
			intent.putExtra("id", sheepId.get(sheepNames.indexOf(name)));
			startActivity(intent);
			break;
		/* Sletter en sau fra database */
		case R.id.deleteSheep:
			if(isNetworkAvailable()){
				new DeleteSheepAction(sheepId.get(sheepNames.indexOf(name))).execute();
				adapter.remove(name);
				database.delete(sheepId.get(sheepNames.indexOf(name)));
				sheepNames.remove(sheepId.get(sheepNames.indexOf(name)));
				sheepId.remove(sheepId.get(sheepNames.indexOf(name)));

				adapter.notifyDataSetChanged();

			}else
				Toast.makeText(SheepMenu.this, "Ingen nettverkstilkobling", Toast.LENGTH_SHORT).show();

			break;
		/* Viser logg for en enkelt sau */
		case R.id.sheepLog:
			Intent intent2 = new Intent(SheepMenu.this, Log.class);
			intent2.putExtra("id", sheepId.get((sheepNames.indexOf(name))));
			intent2.putExtra("name",sheepNames.get(sheepNames.indexOf(name)));
			startActivity(intent2);
			break;

		}
		return true;
	}

	/** Åpner saueprofil */
	@Override
	public void onListItemClick(ListView l, View v, int position, long id) {
		super.onListItemClick(l, v, position, id);
		String sheepName = (String) l.getItemAtPosition(position);
		Intent intent = new Intent(SheepMenu.this, EditSheep.class);
		intent.putExtra("id", sheepId.get(sheepNames.indexOf(sheepName))); //Your id
		intent.putExtra("classFrom", SheepMenu.class.toString());
		startActivityForResult(intent,200);
	}


	@Override
	protected void onResume() {
		super.onResume();
		database.open();
		adapter.clear();
		sheepNames = new ArrayList<String>(database.getSheepNamesFromDatabase());
		sheepId = new ArrayList<Integer>(database.getSheepIdFromDatabase());
		adapter.addAll(sheepNames);
		adapter.notifyDataSetChanged();
		this.onContentChanged();
	}

	@Override
	protected void onPause() {
		super.onPause();
		database.close();
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case android.R.id.home:
			this.finish();

			return true;
		}
		return super.onOptionsItemSelected(item);
	}

	/** @see EditSheep.DeleteSheepAction */
	private class DeleteSheepAction extends AsyncTask<Void,Void,Integer>{
		int id;

		DeleteSheepAction(int id){
			this.id = id;
		}

		@Override
		protected void onPostExecute(Integer result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);

		}

		@Override
		protected Integer doInBackground(Void... params) {
			// TODO Auto-generated method stub
			return delete();
		}

		/**
		 * @return databaserespons Returnerer 200 dersom sauen har blitt slettet fra den eksterne databasen
		 */
		private int delete(){
			HttpClient httpclient = new DefaultHttpClient();
			HttpPost httppost = new HttpPost("http://129.241.126.66/cgi-bin/delsheep.py");

			String idString = Integer.toString(id);
			/* Sender med saueid som parameter til scriptet "delsheep.py" som sletter sauen fra den eksterne databasen */
			try {
				// Add your data
				List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(1);
				nameValuePairs.add(new BasicNameValuePair("sheepid", idString));

				httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));

				// Execute HTTP Post Request
				HttpResponse response = httpclient.execute(httppost);
				return response.getStatusLine().getStatusCode();
			} catch(Exception e){
				e.printStackTrace();
			}
			return 0;
		}
	}

	/** Tråd som håndterer håndterer lagring av logg i den lokale databasen fra server*/
	private class GetLog extends AsyncTask<Void,Void,Integer>{

		@Override
		protected void onPostExecute(Integer result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			if(result == 200){
				// To dismiss the dialog
				Toast.makeText(SheepMenu.this, "Oppdatert", Toast.LENGTH_LONG).show();
			}
			progress.dismiss();

		}

		@Override
		protected Integer doInBackground(Void... params) {
			// TODO Auto-generated method stub
			return getLog();
		}

		/**
		 * @return databaserespons  Returnerer statuskoden fra databasen og lagrer logg dersom responsen er 200
		 */
		private int getLog(){
			String[] logArray;
			DatabaseSuperpower source = new DatabaseSuperpower(SheepMenu.this);
			source.open();

			HttpClient client = new DefaultHttpClient();
			HttpPost post = new HttpPost("http://129.241.126.66/cgi-bin/getlog.py");

			try {

				// Add your data
				List<NameValuePair> valuePairs = new ArrayList<NameValuePair>(1);
				valuePairs.add(new BasicNameValuePair("username", LogginStatus.getUserName(SheepMenu.this)));

				post.setEntity(new UrlEncodedFormEntity(valuePairs));

				HttpResponse resp = client.execute(post);
				String responseBody = getResponseBody(resp);

				if(responseBody.length() > 4){
					logArray = responseBody.trim().split(",");
					ArrayList<Integer> idlist = database.getSheepIdFromDatabase();

					int counter = 0;
					/* Legger det getlog.py returnerer inn i en ContentValue som legges til i logg databasen */
					while(counter < logArray.length){
						ContentValues values = new ContentValues();
						//10 fordi det er antall elementer i databasen
						for(int i = 0; i < 6; i++){
							logArray[counter] = logArray[counter].trim();
							switch(i){
							case 0:
								values.put("sheepId", Integer.parseInt(logArray[counter]));
								break;
							case 1:
								values.put("longitude", Double.parseDouble(logArray[counter]));
								break;
							case 2:
								values.put("latitude", Double.parseDouble(logArray[counter]));
								break;
							case 3:
								values.put("alive", logArray[counter].toLowerCase());
								break;
							case 4:
								values.put("alarm", logArray[counter].toLowerCase());
								break;
							case 5:
								values.put("time", logArray[counter]);
								break;
							}
							counter++;
						}
						if(idlist.contains(values.getAsInteger("sheepId")))
							source.logAdd(values);
					}
				}
				source.close();
				return resp.getStatusLine().getStatusCode();
			}catch(Exception e){
				e.printStackTrace();
			}
			source.close();
			return 0;
		}
	}


	/** Tråd som tvinger oppdatering fra simulatoren */
	private class LogUpdate extends AsyncTask<Void,Void,Integer>{

		@Override
		protected void onPostExecute(Integer result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);

			if(result == 200){
				new SheepUpdate().execute();
				new GetLog().execute();
			}else{
				progress.dismiss();
				Toast.makeText(SheepMenu.this, "Feil..", Toast.LENGTH_LONG).show();
				
			}

		}

		@Override
		protected Integer doInBackground(Void... params) {
			// TODO Auto-generated method stub
			return getSheepInfo();
		}

		private int getSheepInfo(){

			HttpClient client = new DefaultHttpClient();
			HttpPost post = new HttpPost("http://129.241.126.66/cgi-bin/updatesheep.py");

			try {

				// Add your data
				List<NameValuePair> valuePairs = new ArrayList<NameValuePair>(1);
				valuePairs.add(new BasicNameValuePair("username", LogginStatus.getUserName(SheepMenu.this)));

				post.setEntity(new UrlEncodedFormEntity(valuePairs));
				HttpResponse resp = client.execute(post);

				return resp.getStatusLine().getStatusCode();
			}catch(Exception e){
				e.printStackTrace();
			}
			return 0;
		}
	}

	/** Tråd som oppdaterer informasjon om sau */
	private class SheepUpdate extends AsyncTask<Void,Void,Integer>{

		@Override
		protected void onPostExecute(Integer result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
		}

		@Override
		protected Integer doInBackground(Void... params) {
			// TODO Auto-generated method stub
			return update();
		}

		/**
		 * @return databaserespons Returnerer statuskoden fra databasen og lagrer logg dersom responsen er 200
		 */
		private int update(){
			String[] sheepArray;
			DatabaseSuperpower source = new DatabaseSuperpower(SheepMenu.this);
			source.open();

			HttpClient client = new DefaultHttpClient();
			HttpPost post = new HttpPost("http://129.241.126.66/cgi-bin/getsheepinfo.py");

			try {
				// Add your data
				List<NameValuePair> valuePairs = new ArrayList<NameValuePair>(1);
				valuePairs.add(new BasicNameValuePair("username", LogginStatus.getUserName(SheepMenu.this)));

				post.setEntity(new UrlEncodedFormEntity(valuePairs));

				HttpResponse resp = client.execute(post);
				String responseBody = getResponseBody(resp);
				sheepArray = responseBody.trim().split(",");


				int counter = 0;

				/* Legger det getlog.py returnerer inn i en ContentValue som brukes til å oppdatere hver enkelt sau */
				while(counter < sheepArray.length){
					ContentValues values = new ContentValues();
					//10 fordi det er antall elementer i databasen
					for(int i = 0; i < 10; i++){
						sheepArray[counter] = sheepArray[counter].trim();
						switch(i){
						case 0:
							values.put("id", Integer.parseInt(sheepArray[counter]));
							break;
						case 1:
							values.put("longitude", Double.parseDouble(sheepArray[counter]));
							break;
						case 2:
							values.put("latitude", Double.parseDouble(sheepArray[counter]));
							break;
						case 3:
							values.put("name", sheepArray[counter]);
							break;
						case 4:
							values.put("age", sheepArray[counter]);
							break;
						case 5:
							values.put("weight", Integer.parseInt(sheepArray[counter]));
							break;
						case 6:
							values.put("alive", Boolean.parseBoolean(sheepArray[counter]));
							break;
						case 7:
							values.put("alarm", Boolean.parseBoolean(sheepArray[counter]));
							break;
						case 9:
							values.put("health", sheepArray[counter]);
							break;
						}
						counter++;
					}
					source.sheepUpdate(values, values.getAsInteger("id"));
				}
				source.close();
				return resp.getStatusLine().getStatusCode();
			}catch(Exception e){
				e.printStackTrace();
			}
			source.close();
			return 0;
		}        
	}


	/** @see RegisterSheep#getResponseBody(HttpResponse) */
	public String getResponseBody(HttpResponse response) {

		String response_text = null;
		HttpEntity entity = null;
		try {
			entity = response.getEntity();
			response_text = _getResponseBody(entity);
		} catch (ParseException e) {
			e.printStackTrace();
		} catch (IOException e) {
			if (entity != null) {
				try {
					entity.consumeContent();
				} catch (IOException e1) {
				}
			}
		}
		return response_text;
	}

	/** @see RegisterSheep#_getResponseBody(HttpEntity) */
	public String _getResponseBody(final HttpEntity entity) throws IOException, ParseException {

		if (entity == null) {
			throw new IllegalArgumentException("HTTP entity may not be null");
		}

		InputStream instream = entity.getContent();

		if (instream == null) return "";

		if (entity.getContentLength() > Integer.MAX_VALUE) {
			throw new IllegalArgumentException(
					"HTTP entity too large to be buffered in memory");
		}

		String charset = getContentCharSet(entity);

		if (charset == null) charset = HTTP.DEFAULT_CONTENT_CHARSET;

		Reader reader = new InputStreamReader(instream, charset);
		StringBuilder buffer = new StringBuilder();

		try {
			char[] tmp = new char[1024];
			int l;
			while ((l = reader.read(tmp)) != -1) {
				buffer.append(tmp, 0, l);
			}
		} finally {
			reader.close();
		}

		return buffer.toString();
	}

	/** @see RegisterSheep#getContentCharSet(HttpEntity) */
	public String getContentCharSet(final HttpEntity entity) throws ParseException {
		if (entity == null) {
			throw new IllegalArgumentException("HTTP entity may not be null");
		}

		String charset = null;

		if (entity.getContentType() != null) {
			HeaderElement values[] = entity.getContentType().getElements();
			if (values.length > 0) {
				NameValuePair param = values[0].getParameterByName("charset");
				if (param != null) {
					charset = param.getValue();
				}
			}
		}
		return charset;
	}
}
