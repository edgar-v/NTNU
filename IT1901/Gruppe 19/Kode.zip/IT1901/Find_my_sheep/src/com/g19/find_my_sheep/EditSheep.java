package com.g19.find_my_sheep;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.utils.URLEncodedUtils;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.protocol.HTTP;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.DialogFragment;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Klasse som funker som en saueprofil. Har mulighet for å endre informasjon om sau, se logg for sauen og se sauens posisjon på kart
 * @author Hanne Marie Trelease
 */
public class EditSheep extends Activity {

	DatabaseSuperpower source;
	ContentValues values;
	EditText nameedit;
	static EditText birthday;
	EditText weight;
	EditText health;
	int id;
	static String[] birthdate;
	Button delete;
	OnClickListener listener;
	Button editSheep;

	@Override
	protected void onCreate(Bundle savedInstanceState){
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_edit_sheep);
		getActionBar().setDisplayHomeAsUpEnabled(true);


		Bundle b = getIntent().getExtras();
		id = b.getInt("id");

		source = new DatabaseSuperpower(EditSheep.this);
		source.open();
		source.getSheepPositionFromDatabase(id);
		values = source.getSheepInfoFromDatabase(id);

		editSheep = (Button) findViewById(R.id.b3editSheep);
		delete = (Button) findViewById(R.id.b3deleteSheep);
		final Button showLog = (Button) findViewById(R.id.b3Sheeplog);
		final Button showPos = (Button) findViewById(R.id.b3SheepPos);
		final TextView name = (TextView) findViewById(R.id.showSheepName);
		final TextView statusView = (TextView) findViewById(R.id.tvsheepAlive);

		nameedit = (EditText) findViewById(R.id.etSheepName);
		birthday = (EditText) findViewById(R.id.etSheepAge);
		weight = (EditText) findViewById(R.id.etSheepWeight);
		health = (EditText) findViewById(R.id.etSheepHealth);
		birthdate = values.getAsString("age").split("-");

		/** Setter informasjon om sauen inn i tekstfeltene */
		name.setText((CharSequence) values.get("name"));
		nameedit.setText((CharSequence) values.get("name"));
		weight.setText((CharSequence) values.get("weight"));
		health.setText((CharSequence) values.get("health"));
		birthday.setText((CharSequence) birthdate[2]+"."+birthdate[1]+"."+birthdate[0]);
		if(values.get("health").equals("None")) health.setText("");
		if(values.getAsInteger("alarm") == 1)
			statusView.setText("Alarm");
		if(values.getAsInteger("alive") == 1)
			statusView.setText("Levende");
		else
			statusView.setText("Død");

		showLog.setOnClickListener(new View.OnClickListener() {
			@Override
			/** Åpner logaktivitet som viser loggen til en enkelt sau */
			public void onClick(View v) {
				Intent intent = new Intent(EditSheep.this, Log.class);
				intent.putExtra("id", id); 
				intent.putExtra("name", values.getAsString("name"));
				startActivity(intent);
			}
		});

		showPos.setOnClickListener(new View.OnClickListener() {
			/** Åpner kartaktivitet som viser posisjon til en enkelt sau */
			@Override
			public void onClick(View v) {
				Intent intent = new Intent(EditSheep.this, Map.class);
				intent.putExtra("id", id);
				startActivity(intent);
			}
		});

		delete.setOnClickListener(new View.OnClickListener() {
			/** Sletter sau */
			@SuppressLint("NewApi")
			@Override
			public void onClick(View v) {
				if(isNetworkAvailable()){
					delete.setEnabled(false);
					new DeleteSheepAction().execute();
					source.delete(id);
					source.close();
				}else
					Toast.makeText(EditSheep.this, "Ingen nettverkstilkobling", Toast.LENGTH_SHORT).show();
			}
		});

		listener = new OnClickListener() {
			/** Endrer på statusen til knapper og tekstfelt når man trykker på "editSheep" slik at funksjonaliteter blir 
			 * skrudd av og på i forhold til hva man har trykket på, og gjør det mulig å endre informasjon om sau
			 * @see android.view.View.OnClickListener#onClick(android.view.View)
			 */
			@Override
			public void onClick(View v) {
				if(isNetworkAvailable()){
					nameedit.setFocusable(true);
					nameedit.setFocusableInTouchMode(true);
					weight.setFocusable(true);
					weight.setFocusableInTouchMode(true);
					health.setFocusable(true);
					health.setFocusableInTouchMode(true);
					birthday.setFocusable(true);
					birthday.setFocusableInTouchMode(true);
					delete.setVisibility(4);
					showLog.setVisibility(4);
					showPos.setVisibility(4);
					birthday.setOnTouchListener(new OnTouchListener() {

						@Override
						public boolean onTouch(View v, MotionEvent event) {
							if (event.getAction() == MotionEvent.ACTION_UP) {
								showDatePickerDialog(v);
							}
							return false;
						}
					});
					editSheep.setOnClickListener(new View.OnClickListener() {

						@Override
						public void onClick(View v) {
							new EditSheepAction().execute();
							nameedit.setFocusable(false);
							weight.setFocusable(false);
							health.setFocusable(false);
							birthday.setFocusable(false);
							birthday.setOnTouchListener(null);
							delete.setVisibility(0);
							showLog.setVisibility(0);
							showPos.setVisibility(0);
						}
					});
				}else
					Toast.makeText(EditSheep.this, "Ingen nettverkstilkobling", Toast.LENGTH_SHORT).show();
			}
		};
		editSheep.setOnClickListener(listener);
	}

	/**
	 * Åpner dialog som gjør det mulig å velge sauens fødselsdato
	 * @param v  View
	 */
	public void showDatePickerDialog(View v) {
		DialogFragment newFragment = new DatePickerFragment();
		newFragment.show(getFragmentManager(), "datePicker");
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case android.R.id.home:
			this.finish();
			return true;
		}
		return super.onOptionsItemSelected(item);
	}

	/** @see MainActivity#isNetworkAvailable() */
	private boolean isNetworkAvailable() {
		ConnectivityManager connectivityManager 
		= (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
		NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
		return activeNetworkInfo != null && activeNetworkInfo.isConnected();
	}

	@Override
	public void onBackPressed() {
		if(delete.isEnabled()){
			super.onBackPressed();
		} else{
			Toast.makeText(EditSheep.this, "Wait..", Toast.LENGTH_SHORT).show();
		}
	}

	@Override
	protected void onResume() {
		source.open();
		super.onResume();
	}

	@Override
	protected void onPause() {
		source.close();
		super.onPause();
	}

	/**
	 * Tråd som håndterer sletting av sau og avslutter edit-aktiviteten hvis sauen blir slettet
	 */
	private class DeleteSheepAction extends AsyncTask<Void,Void,Integer>{

		@Override
		protected void onPostExecute(Integer result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			if(result != 200){
				delete.setEnabled(true);
			}else{
				finish();
			}
		}

		@Override
		protected Integer doInBackground(Void... params) {
			// TODO Auto-generated method stub
			return delete();
		}


		/**
		 * @return databaserespons Returnerer 200 dersom sauen har blitt slettet fra den eksterne databasen
		 */
		private int delete(){
			HttpClient httpclient = new DefaultHttpClient();
			HttpPost httppost = new HttpPost("http://129.241.126.66/cgi-bin/delsheep.py");

			String idString = Integer.toString(id);
			/* Sender med saueid som parameter til scriptet "delsheep.py" som sletter sauen fra den eksterne databasen */
			try {
				// Add your data
				List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(1);
				nameValuePairs.add(new BasicNameValuePair("sheepid", idString));

				httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));

				// Execute HTTP Post Request
				HttpResponse response = httpclient.execute(httppost);
				return response.getStatusLine().getStatusCode();
			} catch(Exception e){
				e.printStackTrace();
			}
			return 0;
		}
	}

	/** Tråd som håndterer endring av sau */
	private class EditSheepAction extends AsyncTask<Void,Void,Integer>{

		@Override
		protected void onPostExecute(Integer result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			if (result != 200)
			{
				nameedit.setText((CharSequence) values.get("name"));
				birthdate = values.getAsString("age").split("-");
				birthday.setText((CharSequence) birthdate[2]+"."+birthdate[1]+"."+birthdate[0]);
				weight.setText((CharSequence) values.get("weight"));
				health.setText((CharSequence) values.get("health"));
			}
			editSheep.setOnClickListener(listener);
		}

		@Override
		protected Integer doInBackground(Void... params) {
			// TODO Auto-generated method stub
			return edit();
		}

		/**
		 * Legger informasjonen om en sau inn i databasen
		 * @return databaserespons	returnerer 200 dersom endringene ble gjennomført
		 */
		private int edit(){
			HttpClient httpclient = new DefaultHttpClient();
			HttpPost httppost = new HttpPost("http://129.241.126.66/cgi-bin/editsheep.py");

			String nameString = nameedit.getText().toString();
			String ageString = birthdate[0] + "-" + birthdate[1] + "-" + birthdate[2];
			String weightString = weight.getText().toString();
			String healthString = health.getText().toString();
			String idString = Integer.toString(id);

			/* Sender med saueinformasjon som parametere til scriptet "editsheep.py" som endrer informasjonen i den eksterne databasen */
			try {
				ContentValues newData = new ContentValues();
				// Add your data
				List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(5);
				nameValuePairs.add(new BasicNameValuePair("sheepid", idString));
				nameValuePairs.add(new BasicNameValuePair("name", nameString));
				nameValuePairs.add(new BasicNameValuePair("age", ageString));
				nameValuePairs.add(new BasicNameValuePair("weight", weightString));
				nameValuePairs.add(new BasicNameValuePair("comment", healthString));
				String values = URLEncodedUtils.format(nameValuePairs, HTTP.UTF_8);
				StringEntity entity = new StringEntity(values, HTTP.UTF_8);
				entity.setContentType(URLEncodedUtils.CONTENT_TYPE);

				httppost.setEntity(entity);

				// Execute HTTP Post Request
				HttpResponse response = httpclient.execute(httppost);
				if(response.getStatusLine().getStatusCode() == 200){
					newData.put("name",nameString);
					newData.put("age",ageString);
					newData.put("weight", weightString);
					newData.put("health", healthString);

					source.sheepUpdate(newData,id);
				}
				return response.getStatusLine().getStatusCode();
			} catch(Exception e){
				e.printStackTrace();
			}
			return 0;
		}
	}

	/**
	 * Datovelgerdialog som gir mulighet for å velge saus fødselsdato
	 */
	public static class DatePickerFragment extends DialogFragment
	implements DatePickerDialog.OnDateSetListener {

		@Override
		public Dialog onCreateDialog(Bundle savedInstanceState) {
			// Use the current date as the default date in the picker
			final Calendar c = Calendar.getInstance();
			int year = c.get(Calendar.YEAR);
			int month = c.get(Calendar.MONTH);
			int day = c.get(Calendar.DAY_OF_MONTH);


			// Create a new instance of DatePickerDialog and return it
			return new DatePickerDialog(getActivity(), this, year, month, day);
		}

		@Override
		public void onDateSet(DatePicker view, int y, int m, int d) {
			birthdate = new String[3];
			birthdate[0] = ""+y;
			birthdate[1] = ""+(m+1);
			birthdate[2] = ""+d;
			birthday.setText(birthdate[2]+"."+birthdate[1]+"."+birthdate[0]);
		}
	}
}
