/** Automatically generated file. DO NOT MODIFY */
package com.g19.find_my_sheep;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}