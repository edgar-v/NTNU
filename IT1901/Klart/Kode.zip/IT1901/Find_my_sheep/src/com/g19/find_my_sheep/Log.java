package com.g19.find_my_sheep;

import java.util.ArrayList;
import java.util.Locale;

import android.annotation.SuppressLint;
import android.app.ListActivity;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Filter;
import android.widget.TextView;

/**
 * Klasse som viser sauelogg
 * @author Hanne Marie Trelease
 */
public class Log extends ListActivity {

	int id;
	String name;
	DatabaseSuperpower source;
	ArrayList<ContentValues> log;
	Bundle b;
	ArrayAdapter<ContentValues> adapter;

	// May also be triggered from the Activity
	@Override
	public void onCreate(Bundle savedInstanceState){
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_log);
		getActionBar().setDisplayHomeAsUpEnabled(true);
		source = new DatabaseSuperpower(this);
		source.open();
		b = getIntent().getExtras();
		update();

		final EditText inputSearch = (EditText) findViewById(R.id.inputSearch);
		inputSearch.setFocusable(true);
		inputSearch.setFocusableInTouchMode(true);

		adapter = new CustomArrayAdapter(Log.this, R.layout.log_list, log);



		setListAdapter(adapter);
		inputSearch.addTextChangedListener(new TextWatcher() {

			/** Oppdaterer lista slik at bare det som søkes på blir vist */
			@Override
			public void onTextChanged(CharSequence cs, int start, int count, int after) {
				adapter.getFilter().filter(cs);  
				adapter.notifyDataSetChanged();
			}

			@Override
			public void beforeTextChanged(CharSequence cs, int start, int count, int after) {
				// TODO Auto-generated method stub

			}

			@Override
			public void afterTextChanged(Editable s) {
				// TODO Auto-generated method stub                         
			}
		});

		if(log.size() > 0){
			TextView display = (TextView) findViewById(R.id.tvData);
			display.setVisibility(4);
		}


	}

	protected void onPause(){
		super.onPause();
		source.close();
	}
	
	@Override
	protected void onResume() {
		super.onResume();
		source.open();
		adapter.clear();
		b = getIntent().getExtras();
		update();
		adapter.addAll(log);
		adapter.notifyDataSetChanged();
	}

	/** Henter informasjonen som skal inn i loggen fra den lokale databasen */
	private void update(){
		if(b != null){
			id = b.getInt("id");
			name = b.getString("name");
			log = new ArrayList<ContentValues>(source.getsheepLog(id));
			for(ContentValues v: log){
				v.put("name", name);
			}
		}
		else{
			log = new ArrayList<ContentValues>(source.getLog());
		}
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case android.R.id.home:
			this.finish();
			return true;
		}
		return super.onOptionsItemSelected(item);
	}

	/** Egendefinert ArrayAdapter som bestemmer hvordan logginformasjonen skal vises i programmet */
	@SuppressLint("ResourceAsColor")
	public class CustomArrayAdapter extends ArrayAdapter<ContentValues> {
		private final Context context;
		private final ArrayList<ContentValues> values;
		private ArrayList<ContentValues> list;

		public CustomArrayAdapter(Context context, int layout, ArrayList<ContentValues> v) {
			super(context, layout, v);
			this.context = context;
			this.values = new ArrayList<ContentValues>(v);
			list = new ArrayList<ContentValues>(v);
		}

		/** Klasse med TextViews og Buttons som er definert i xml-en*/
		class ViewHolder {   
			TextView nameView;
			TextView dateView;
			TextView timeView;
			TextView statusView;
			TextView latView;
			TextView lngView;
			Button showPos;
		}

		@SuppressLint("ResourceAsColor")
		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			final int pos = position;

			LayoutInflater inflater = (LayoutInflater) context
					.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			View v = convertView;
			ViewHolder holder = null;

			if(v == null){
				v = inflater.inflate(R.layout.log_list, null);
				holder = new ViewHolder();
				holder.nameView = (TextView) v.findViewById(R.id.tvNameLog);
				holder.dateView = (TextView) v.findViewById(R.id.tvDate);
				holder.timeView = (TextView) v.findViewById(R.id.tvTime);
				holder.statusView = (TextView) v.findViewById(R.id.tvShowSheepStatusLog);
				holder.latView = (TextView) v.findViewById(R.id.tvLat);
				holder.lngView = (TextView) v.findViewById(R.id.tvLng);

				holder.showPos = (Button) v.findViewById(R.id.b3showLogPosition);
				v.setTag(holder);
			} else
				holder = (ViewHolder) v.getTag();


			String[] time = list.get(position).getAsString("time").split("[-\\s]");
			holder.nameView.setText(list.get(position).getAsString("name"));
			holder.dateView.setText(time[2]+"."+time[1]+"."+time[0]);
			holder.timeView.setText(time[3]);
			holder.latView.setText(list.get(position).getAsString("latitude"));
			holder.lngView.setText(list.get(position).getAsString("longitude"));

			if (list.get(position).getAsString("alarm").equalsIgnoreCase("true")){
				holder.statusView.setText("Alarm");
				holder.statusView.setTextColor(Color.RED);
			}else if(list.get(position).getAsString("alive").equalsIgnoreCase("true")){
				holder.statusView.setText("Levende");
				holder.statusView.setTextColor(Color.BLACK);
			}else if(list.get(position).getAsString("alive").equalsIgnoreCase("false")){
				holder.statusView.setText("Død");
				holder.statusView.setTextColor(Color.RED);
			}

			holder.showPos.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {
					Intent intent = new Intent(Log.this, Map.class);
					intent.putExtra("name", list.get(pos).getAsString("name"));
					intent.putExtra("latitude", list.get(pos).getAsDouble("latitude"));
					intent.putExtra("longitude", list.get(pos).getAsDouble("longitude"));
					intent.putExtra("alive", list.get(pos).getAsString("alive"));
					intent.putExtra("alarm", list.get(pos).getAsString("alarm"));
					startActivity(intent);

				}
			});
			return v;
		}

		/** 
		 * Søkefunksjon som sjekker om teksten som er skrevet i søkefeltet finnes i lista
		 * @see android.widget.ArrayAdapter#getFilter()
		 */
		@Override
		public Filter getFilter(){
			Filter filter = new Filter() {
				@Override
				protected FilterResults performFiltering(CharSequence constraint) {
					FilterResults result = new FilterResults();
					// if constraint is empty return the original names

					if(constraint == null ||constraint.length() == 0 ){
						result.values = values;
						result.count = values.size();
						return result;
					}

					ArrayList<ContentValues> newlist = new ArrayList<ContentValues>();
					String filterString = constraint.toString().toLowerCase(Locale.getDefault());



					ArrayList<String> dates = new ArrayList<String>();
					ArrayList<String> status = new ArrayList<String>();

					for(int i = 0; i < values.size(); i++){
						String[] time = values.get(i).getAsString("time").split("[-\\s]");
						dates.add(time[2]+"."+time[1]+"."+time[0]);
						if(((String) values.get(i).get("alarm")).equalsIgnoreCase("true"))
							status.add("Alarm");
						else if(((String) values.get(i).get("alive")).equalsIgnoreCase("true"))
							status.add("Levende");
						else if(((String) values.get(i).get("alive")).equalsIgnoreCase("false"))
							status.add("Død");
					}

					for(int i = 0; i < values.size(); i++){
						ContentValues v = values.get(i);
						String date = dates.get(i);
						if (v.getAsString("name").toLowerCase(Locale.getDefault())
								.contains(filterString))
							newlist.add(v);
						if(v.getAsString("longitude").toLowerCase(Locale.getDefault())
								.contains(filterString))
							newlist.add(v);
						if(v.getAsString("latitude").toLowerCase(Locale.getDefault())
								.contains(filterString))
							newlist.add(v);
						if(v.getAsString("time").toLowerCase(Locale.getDefault())
								.contains(filterString))
							newlist.add(v);
						if(status.get(i).toLowerCase(Locale.getDefault()).contains(filterString))
							newlist.add(v);
						if(date.toLowerCase(Locale.getDefault()).contains(filterString))
							newlist.add(v);

					}

					result.values = newlist;
					result.count = newlist.size();

					return result;
				}

				@SuppressWarnings("unchecked")
				@Override
				protected void publishResults(CharSequence constraint, FilterResults results) {
					list = (ArrayList<ContentValues>)results.values;
					clear();
					for(ContentValues v: list){
						add(v);
					}
					notifyDataSetChanged();
				}
			};
			return filter;
		}
	} 

}