package com.g19.find_my_sheep;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.http.HeaderElement;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.HttpResponseException;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.protocol.HTTP;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.gcm.GoogleCloudMessaging;

import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.ParseException;
import android.os.AsyncTask;
import android.os.Bundle;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.json.*;

/**
 * Hovedklassen som styrer brukerinnlogging, henter informasjon fra databasen ved innloggig og 
 * styrer google cloud messaging.
 * 
 * @author Fredrik Borgen Tørnvall
 * @author Hanne Marie Trelease
 * @author Edgar Vedvik
 */
public class MainActivity extends Activity {

	Context context;
	String SENDER_ID = "148211728007";
	String regid;
	Button login;
	ProgressDialog progress;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		if(LogginStatus.getUserName(MainActivity.this).length() != 0)
		{
			map();
		}
		super.onCreate(savedInstanceState);
		if (!checkPlayServices()) {
			Log.i("GCM", "No play services");
		}
		setContentView(R.layout.activity_main);
		context = getApplicationContext();

		login = (Button) findViewById(R.id.b3Login);
		Button reg = (Button) findViewById(R.id.b3Reg);
		Button reset = (Button) findViewById(R.id.b3Recover);

		login.setOnClickListener(new View.OnClickListener() {
			/** Starter logg inn-prosessen i en ny tråd
			 * @see android.view.View.OnClickListener#onClick(android.view.View)
			 */
			@Override
			public void onClick(View arg0) {
				if(isNetworkAvailable()){
					login.setEnabled(false);
					progress = new ProgressDialog(MainActivity.this, AlertDialog.THEME_HOLO_DARK);
					progress.setTitle("Logg inn");
					progress.setMessage("Logger inn...");
					progress.show();
					new loginAction().execute();
				}else
					Toast.makeText(MainActivity.this, "Ingen nettverkstilkobling", Toast.LENGTH_SHORT).show();
			}	
		});

		reg.setOnClickListener(new View.OnClickListener() {
			/** Starter registrer bruker-aktivitet*/
			@Override
			public void onClick(View arg0) {
				Intent intent = new Intent(MainActivity.this, RegUser.class);
				startActivity(intent);
			}
		});

		reset.setOnClickListener(new View.OnClickListener() {
			/** Starter tilbakestill passort-aktivitet*/
			@Override
			public void onClick(View arg0) {
				Intent intent = new Intent(MainActivity.this, RecoverPassword.class);
				startActivity(intent);
			}
		});

	}

	
	/**
	 * Sjekker om nettverk er tilgjengelig
	 * @return Nettverktilgjengelighet
	 */
	private boolean isNetworkAvailable() {
		ConnectivityManager connectivityManager 
		= (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
		NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
		return activeNetworkInfo != null && activeNetworkInfo.isConnected();
	}

	
	/**
	 * Hvis google play services ikke er tilgjengelig returneres false og applikasjonen avsluttes
	 * @return google play status  
	 */
	private boolean checkPlayServices() {
		int resultCode = GooglePlayServicesUtil.isGooglePlayServicesAvailable(this);
		if (resultCode != ConnectionResult.SUCCESS) {
			if (GooglePlayServicesUtil.isUserRecoverableError(resultCode)) {
				GooglePlayServicesUtil.getErrorDialog(resultCode, this, 9000).show();
			}
			else
			{
				Log.i("GCM", "This device is not supported");
				finish();
			}
			return false;
		}
		return true;
	}

	/** 
	 * Trådklasse som håndterer innloggingsprosessen
	 * Starter kart-aktivitet hvis brukernavn og passord er riktig
	 */
	private class loginAction extends AsyncTask<Void,Void,Boolean>{

		@Override
		protected void onPostExecute(Boolean result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);

			TextView display = (TextView) findViewById(R.id.tvLog);
			display.setText(result.toString());

			if(result == false){
				login.setEnabled(true);	
			}
			else {
				map();
			}
			progress.dismiss();
		}

		@Override
		protected Boolean doInBackground(Void... params) {
			// TODO Auto-generated method stub
			return login();
		}
	}

	/**
	 * @return databaserespons  Returnerer true hvis brukernavn og passord er riktig
	 */
	private Boolean login(){
		// Create a new HttpClient and Post Header
		/* Kontakter script som sjekker med databasen om brukernavn og passord er riktig
		 */
		HttpClient httpclient = new DefaultHttpClient();
		HttpPost httppost = new HttpPost("http://129.241.126.66/cgi-bin/login.py");

		final EditText user = (EditText) findViewById(R.id.etUser);
		final EditText pass = (EditText) findViewById(R.id.etPassword);

		String username = user.getText().toString();
		String password = pass.getText().toString();
		String registrationId = "";
		/* Setter opp Google Cloud Messaging så enheten kan få push-meldinger */
		try {
			GoogleCloudMessaging gcm = GoogleCloudMessaging.getInstance(context);
			registrationId = gcm.register(SENDER_ID);
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}
		
		/* Sender med brukernavn, passord og google cloud messaging id som parametere til scriptet */
		try {
			// Add your data
			List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(2);
			nameValuePairs.add(new BasicNameValuePair("username", username));
			nameValuePairs.add(new BasicNameValuePair("password", password));
			nameValuePairs.add(new BasicNameValuePair("gcm", registrationId));
			httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));

			// Execute HTTP Post Request
			ResponseHandler<String> responseHandler = new BasicResponseHandler();
			String response = httpclient.execute(httppost, responseHandler);

			if(response != null){
				//String responseBody = getResponseBody(response);
				/* Får informasjon om bruker, sauer og logg fra databasen */
				JSONObject object = (JSONObject) new JSONTokener(response).nextValue();
				JSONObject userjson = object.getJSONObject("user");
				JSONArray sheepjson = object.getJSONArray("sheep");
				JSONArray logjson = object.getJSONArray("log");

				storeUserInfo(userjson);
				storeSheepInfo(sheepjson);
				storeLogInfo(logjson);

				return true;
			}
		} catch (ClientProtocolException e) {
			// TODO Auto-generated catch block
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return false;
	}

	/** 
	 * Om responsen fra server er 200 (OK), lagres brukernavnet i appen, til senere bruk. 
	 * @param json
	 */
	private void storeUserInfo(JSONObject json){
		try {
			LogginStatus.setUserName(MainActivity.this, json.getString("username"));
			LogginStatus.setName(MainActivity.this, json.getString("name"));
			LogginStatus.setEmail(MainActivity.this, json.getString("email"));
			LogginStatus.setTlf(MainActivity.this, json.getString("tlf"));
			LogginStatus.setBackup(MainActivity.this, json.getString("secondary_email"));
			LogginStatus.setGcmId(MainActivity.this, json.getString("gcm"));
		} catch (JSONException e) {
			System.out.println(e.getMessage());
		}
	}

	/** 
	 * Lagrer info om alle sauene i den lokale databasen 
	 * @param json
	 */
	private void storeSheepInfo(JSONArray json){
		DatabaseSuperpower source = new DatabaseSuperpower(MainActivity.this);
		source.open();
		ContentValues sheep = new ContentValues();
		try {
			for (int i = 0; i < json.length(); i++) {
				JSONObject sheepJson = json.getJSONObject(i);
				sheep.put("id", sheepJson.getInt("id"));
				sheep.put("longitude", sheepJson.getDouble("longitude"));
				sheep.put("latitude", sheepJson.getDouble("latitude"));
				sheep.put("name", sheepJson.getString("name"));
				sheep.put("age", sheepJson.getString("age"));
				sheep.put("weight", sheepJson.getInt("weight"));
				sheep.put("alive", sheepJson.getBoolean("alive"));
				sheep.put("alarm", sheepJson.getBoolean("alarm"));
				if (sheepJson.has("comment")) {
					sheep.put("health", sheepJson.getString("comment"));
				}
				source.startUp(sheep);
			} 
		}	
		catch (JSONException e) {
			System.out.println(e.getMessage());
		} finally {
			source.close();
		}
	}

	/** 
	 * Lagrer logg-info om alle sauene i den lokale databasen
	 * @param json
	 */
	private void storeLogInfo(JSONArray json) {
		DatabaseSuperpower source = new DatabaseSuperpower(MainActivity.this);
		source.open();
		ContentValues values = new ContentValues();
		try {
			for (int i = 0; i < json.length(); i++) {
				JSONObject logjson = json.getJSONObject(i);
				values.put("sheepId", logjson.getInt("sheep"));
				values.put("longitude", logjson.getDouble("longitude"));
				values.put("latitude", logjson.getDouble("latitude"));
				values.put("alive", logjson.getString("alive"));
				values.put("alarm", logjson.getString("alarm"));
				values.put("time", logjson.getString("timestamp"));
				source.logAdd(values);
			}
		} catch (JSONException e){
			System.out.println(e.getMessage());
		}
		finally {
			source.close();
		}
	}

	/** Denne metoden kjører kartaktiviteten og avslutter MainActivity */
	public void map(){
		Intent intent = new Intent(this, Map.class);
		startActivity(intent);
		finish();

	}
}