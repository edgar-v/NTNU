package com.g19.find_my_sheep;

import java.lang.reflect.Field;
import java.util.ArrayList;

import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.GoogleMap.*;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

import android.app.ActionBar;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.ViewConfiguration;

/**
 * @author Fredrik Borgen Tørnvall
 * @author Hanne Marie Trelease
 *
 *	Denne klassen viser kartet og håndterer alle markørene. 
 */
public class Map extends Activity implements OnMarkerClickListener, OnInfoWindowClickListener{
	private GoogleMap map;
	boolean markerClicked;
	DatabaseSuperpower sheepLoc;
	LatLngBounds.Builder builder = new LatLngBounds.Builder();
	LatLngBounds bounds;
	Bundle b;
	ActionBar actionbar;

	ArrayList<Integer> idlist = new ArrayList<Integer>();

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.map);
		actionbar = getActionBar();

		sheepLoc = new DatabaseSuperpower(this);
		sheepLoc.open();

		map = ((RetainMapFragment) getFragmentManager().findFragmentById(R.id.map))
				.getMap();
		map.setOnMarkerClickListener(this);
		map.setOnInfoWindowClickListener(this);


		addSheepMarkers();

		if(bounds != null){
			int padding = 0; // offset from edges of the map in pixels
			CameraUpdate cu = CameraUpdateFactory.newLatLngBounds(bounds, 300, 300, padding);
			map.moveCamera(cu);
		}

		getOverflowMenu(); 	

	}

	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		sheepLoc.open();
		map.clear();
		addSheepMarkers();

	}

	/**
	 * addSheepMarkers henter ut kordinatene fra den lokale databasen for så å sette markører på kartet.
	 * Den setter også navn og id på markøren. 
	 */
 
	protected void addSheepMarkers(){
		b = getIntent().getExtras();
		/** Hvis  */
		if(b == null){
			actionbar.show();
			idlist = new ArrayList<Integer>(sheepLoc.getSheepIdFromDatabase());

			ArrayList<ContentValues> dfg = new ArrayList<ContentValues>();
			ArrayList<ContentValues> status = new ArrayList<ContentValues>();

			for(int i = 0; i < idlist.size(); i++){
				dfg.add(sheepLoc.getSheepPositionFromDatabase(idlist.get(i))) ;
				status.add(sheepLoc.getSheepStatusFromDatabase(idlist.get(i)));
				double lat = dfg.get(i).getAsDouble("latitude");
				double lng = dfg.get(i).getAsDouble("longitude");
				boolean alive = true;
				if(status.get(i).getAsInteger("alive") != 1)
					alive = false;

				LatLng latlng = new LatLng(lng, lat);
				int drawable;

				if(status.get(i).getAsInteger("alarm") == 1)
					drawable = R.drawable.alarmmarker;
				else if(alive)
					drawable = R.drawable.marker;
				else
					drawable = R.drawable.tombstone_icon;

				map.addMarker(new MarkerOptions()
				.position(latlng)
				.draggable(false)
				.snippet("ID: "+idlist.get(i))
				.title(dfg.get(i).getAsString("name"))
				.icon(BitmapDescriptorFactory.fromResource(drawable)));
				markerClicked = false;
				builder.include(latlng);
				bounds = builder.build();
			}
		}else{
			actionbar.hide();
			ContentValues values;
			int drawable;
			if(b.containsKey("alive")){
				values = new ContentValues();
				values.put("name", b.getString("name"));
				values.put("latitude", b.getDouble("latitude"));
				values.put("longitude", b.getDouble("longitude"));
				if(b.getString("alarm").equals("true"))
					drawable = R.drawable.alarmmarker;
				else if(b.getString("alive").equals("true"))
					drawable = R.drawable.marker;
				else
					drawable = R.drawable.tombstone_icon;
			}else{
				ContentValues status = sheepLoc.getSheepStatusFromDatabase(b.getInt("id"));
				values = sheepLoc.getSheepPositionFromDatabase(b.getInt("id"));
				if(status.getAsInteger("alarm") ==1)
					drawable = R.drawable.alarmmarker;
				else if(status.getAsInteger("alive") == 1)
					drawable = R.drawable.marker;
				else
					drawable = R.drawable.tombstone_icon;
			}
			Double lat = values.getAsDouble("latitude");
			Double lng = values.getAsDouble("longitude");
			String name = values.getAsString("name");

			LatLng latlng = new LatLng(lng, lat);
			map.addMarker(new MarkerOptions()
			.position(latlng)
			.draggable(false)
			.title(name)
			.icon(BitmapDescriptorFactory.fromResource(drawable)));
			markerClicked = false;
			CameraPosition cameraPosition = new CameraPosition.Builder().target(latlng).zoom(12).build();
			map.animateCamera(CameraUpdateFactory.newCameraPosition(cameraPosition));
		}
	}

	@Override
	protected void onPause() {
		// TODO Auto-generated method stub
		super.onPause();
		sheepLoc.close();
	}

	@Override
	public void onInfoWindowClick(Marker marker) {
		if(marker.getSnippet() != null){
			// TODO Auto-generated method stub
			Intent intent = new Intent(Map.this, EditSheep.class);
			//marker.getTitle();
			intent.putExtra("id", Integer.parseInt(marker.getSnippet().substring(4))); //Your id
			startActivity(intent);
		}

	}

	/**
	 * Åpner overflowmenu på enheter som ikke får denne automatisk
	 */
	private void getOverflowMenu() {
		try {
			ViewConfiguration config = ViewConfiguration.get(this);
			Field menuKeyField = ViewConfiguration.class.getDeclaredField("sHasPermanentMenuKey");
			if(menuKeyField != null) {
				menuKeyField.setAccessible(true);
				menuKeyField.setBoolean(config, false);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}


	@Override
	public boolean onOptionsItemSelected(MenuItem item){
		switch (item.getItemId()) {
		case R.id.action_logout:
			/**  Sletter den lokale sauedatabasen og brukernavn for å unngå at man får opp feil sauer hvis man logger på med annen konto*/
			LogginStatus.setUserName(this, null);
			sheepLoc.deleteDatabase();
			sheepLoc.close();
			LogginStatus.setGcmId(this, null);
			Intent intent = new Intent(Map.this, MainActivity.class);
			startActivity(intent);

			finish();

			break;
		case R.id.action_sat:
			map.setMapType(GoogleMap.MAP_TYPE_SATELLITE);
			break;
		case R.id.action_map:
			map.setMapType(GoogleMap.MAP_TYPE_NORMAL);
			break;
		case R.id.action_ter:
			map.setMapType(GoogleMap.MAP_TYPE_TERRAIN);
			break;

		case R.id.sheep_menu:
			Intent intent3 = new Intent(this, SheepMenu.class);
			intent3.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
			startActivity(intent3);
			break;

		case R.id.user_menu:
			Intent intent2 = new Intent(this, UserMenu.class);
			intent2.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
			startActivity(intent2);
			break;

		default:
			return super.onOptionsItemSelected(item);
		}
		return true;
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}



	@Override
	public boolean onMarkerClick(Marker marker) {
		// TODO Auto-generated method stub

		marker.showInfoWindow();
		
		// Koden som er komentert ut under er starten på en gårdløsning som vi ikke hadde tid til å implementere. 
		//		
		//		if(markerClicked)
		//	    {
		//	        if(polygon != null)
		//	        {
		//	            polygon.remove();
		//	            polygon = null;
		//	        }
		//
		//	        polygonOptions.add(marker.getPosition());
		//	        polygonOptions.strokeColor(Color.BLACK);
		//	        polygonOptions.strokeWidth(5);
		//	        polygonOptions.fillColor(0x884d4d4d);
		//
		//	        polygon = map.addPolygon(polygonOptions);
		//	        marker.remove();
		//
		//	    }
		//	    else    
		//	    {
		//	        if(polygon != null)
		//	        {
		//	            polygon.remove();
		//	            polygon = null;
		//	        }
		//
		//	        polygonOptions = new PolygonOptions().add(marker.getPosition());
		//	        markerClicked = true;
		//	        marker.remove();
		//	    }

		return true;
	}
} 
