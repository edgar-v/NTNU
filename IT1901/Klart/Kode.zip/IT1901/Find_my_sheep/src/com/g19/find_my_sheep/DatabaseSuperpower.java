package com.g19.find_my_sheep;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.http.NameValuePair;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

/**
 * Klasse med metoder for henting fra og lagring i den lokale databasen
 * @author Edgar Vedvik
 * @author Hanne Marie Trelease
 */
public class DatabaseSuperpower {

	// Database fields
	private SQLiteDatabase database;
	private Database dbHelper;

	public DatabaseSuperpower(Context context) {
		dbHelper = new Database(context);
	}

	public void open() throws SQLException {
		database = dbHelper.getWritableDatabase();
	}

	public void close() {
		dbHelper.close();
	}

	/** 
	 * Legger inn ny informasjon om sau ved oppdatering 
	 * @param values  Informasjonen om sauen som skal endres
	 * @param id  Sauens id
	 */
	public void sheepUpdate(ContentValues values, int id){
		database.update(Database.TABLE_SHEEP,values,"id="+id,null);
	}

	/** Sletter all info i databasen */
	public void deleteDatabase(){
		dbHelper.delete(database);
	}

	/**
	 * Legger til ny sau når man registrerer ny
	 * @param values  Informasjon om ny sau
	 */
	public void sheepAdd(List<NameValuePair> values){
		ContentValues contentValues = new ContentValues();
		for (NameValuePair value : values) {
			if(!value.getName().equals("username"))
				contentValues.put(value.getName(), value.getValue());
		}
		contentValues.put("alive", true);
		contentValues.put("alarm", false);
		database.insert(Database.TABLE_SHEEP, null, contentValues);
	}

	/**
	 * Legger til logg for en uke ved innlogging og ny logg ved oppdatering
	 * @param values  Logginformasjon
	 */
	public void logAdd(ContentValues values){
		String[] val = {"time"};
		Cursor cursor = database.query(Database.TABLE_LOG, val, "sheepId="+ values.get("sheepId"),null, null, null, null);
		cursor.moveToFirst();

		Calendar calendar = Calendar.getInstance();
		int year = calendar.get(Calendar.YEAR);
		int month = calendar.get(Calendar.MONTH) + 1;
		int day = calendar.get(Calendar.DAY_OF_MONTH);

		/* Sjekker om logginformasjonen som blir lagt inn er eldre enn en uke */
		if(day < 7){
			if(month == 1){
				year = year-1;
				month = 12;
				day = 24+day;
			} else{
				month = (month)-1;
				calendar.set(Calendar.MONTH, (month-1));
				int daysinmonth = calendar.getActualMaximum(Calendar.DAY_OF_MONTH);
				day = (daysinmonth-7)+day;
			}
		} else{
			day = day-7;
		}

		String monthString = Integer.toString(month);
		String dayString = Integer.toString(day);

		if(monthString.length() < 2) monthString = "0"+month;
		if(dayString.length() < 2) dayString = "0"+day;

		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		boolean finnes = false;

		while(!finnes && !cursor.isAfterLast()){
			if(values.getAsString("time").equals(cursor.getString(0))) finnes = true;
			cursor.moveToNext();
		}

		cursor.close();

		if(!finnes){
			String[] time = values.getAsString("time").split("[-\\s]");
			if(time[1].length() < 2) time[1] = "0"+time[1];
			if(time[2].length() < 2) time[2] = "0"+time[2];

			try {
				Date logDate = sdf.parse(time[0]+"-"+time[1]+"-"+time[2]);
				Date lastweek = sdf.parse(year+"-"+monthString+"-"+dayString);
				if(!logDate.before(lastweek)) 
					database.insert(Database.TABLE_LOG, null, values);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	
	/**
	 * Sletter logg som er eldre enn en uke
	 * @param times Tider i loggen
	 */
	public void deleteLogDates(ArrayList<String> times){
		Calendar calendar = Calendar.getInstance();
		int year = calendar.get(Calendar.YEAR);
		int month = calendar.get(Calendar.MONTH) + 1;
		int day = calendar.get(Calendar.DAY_OF_MONTH);


		if(day < 7){
			if(month == 1){
				year = year-1;
				month = 12;
				day = 24+day;
			} else{
				month = (month)-1;
				calendar.set(Calendar.MONTH, (month-1));
				int daysinmonth = calendar.getActualMaximum(Calendar.DAY_OF_MONTH);
				day = (daysinmonth-7)+day;
			}
		} else{
			day = day-7;
		}


		String monthString = Integer.toString(month);
		String dayString = Integer.toString(day);

		if(monthString.length() < 2) monthString = "0"+month;
		if(dayString.length() < 2) dayString = "0"+day;

		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Date lastweek = null;
		try {
			lastweek = sdf.parse(year+"-"+monthString+"-"+dayString);
		} catch (ParseException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		for(int i = 0; i < times.size(); i++){
			String[] date = times.get(i).split("[-\\s]");
			try {
				Date logDate = sdf.parse(date[0]+"-"+date[1]+"-"+date[2]);
				if(lastweek != null && logDate.before(lastweek)) 
					database.delete(Database.TABLE_LOG, "time=?", new String[] {times.get(i)});
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}	
		}
	}

	/**
	 * Henter logg for en enkelt sau
	 * @param id  Sauens id
	 * @return values
	 */
	public ArrayList<ContentValues> getsheepLog(int id){
		ArrayList<ContentValues> values = new ArrayList<ContentValues>();
		ArrayList<String> times = new ArrayList<String>();
		Cursor cursor = database.query(Database.TABLE_LOG, null, "sheepId="+id, null, null, null, "time");
		cursor.moveToLast();
		for(int i = 0; i < cursor.getCount(); i++){
			ContentValues val = new ContentValues();
			for(int j = 0; j < cursor.getColumnCount(); j++){
				val.put(cursor.getColumnName(j), cursor.getString(j));
				if(cursor.getColumnName(j).equals("time"))
					if(!times.contains(cursor.getString(j)))
						times.add(cursor.getString(j));
			}
			values.add(val);
			cursor.moveToPrevious();
		}
		deleteLogDates(times);
		cursor.close();
		return values;
	}

	/**
	 * Henter logg for alle sauer
	 * @return values
	 */
	public ArrayList<ContentValues> getLog(){
		ArrayList<ContentValues> values = new ArrayList<ContentValues>();
		ArrayList<String> times = new ArrayList<String>();
		Cursor cursor = database.query(Database.TABLE_LOG, null, null, null, null, null, "time");
		cursor.moveToLast();
		ArrayList<Integer> id = getSheepIdFromDatabase();
		ArrayList<String> names = getSheepNamesFromDatabase();
		for(int i = 0; i < cursor.getCount(); i++){
			ContentValues val = new ContentValues();
			boolean exist = false;
			for(int j = 0; j < cursor.getColumnCount(); j++){
				val.put(cursor.getColumnName(j), cursor.getString(j));
				if(cursor.getColumnName(j).equals("sheepId")){
					if(id.indexOf(cursor.getInt(j)) != -1){
						val.put("name", names.get(id.indexOf(cursor.getInt(j))));
						exist = true;

					}
				}

				if(cursor.getColumnName(j).equals("time"))
					if(!times.contains(cursor.getString(j)))
						times.add(cursor.getString(j));
			}
			if(exist)
				values.add(val);
			cursor.moveToPrevious();
		}
		deleteLogDates(times);
		cursor.close();
		return values;
	}

	/**
	 * Legger til sauer ved innlogging
	 * @param values  Informasjon om sau
	 */
	public void startUp(ContentValues values){
		if(getSheepIdFromDatabase().contains(values.get("id"))){
			sheepUpdate(values, values.getAsInteger("id"));
		} else{
			database.insert(Database.TABLE_SHEEP, null, values);
		}
	}

	
	/**
	 * Sletter info og logg for en enkelt sau
	 * @param id Sauens id
	 */
	public void delete(int id){
		database.delete(Database.TABLE_SHEEP, "id="+id,null);
		database.delete(Database.TABLE_LOG, "sheepId="+id,null);
	}

	/**
	 * Henter informasjon om en sau
	 * @param id  Sauens id
	 * @return values
	 */
	public ContentValues getSheepInfoFromDatabase(int id){
		ContentValues values = new ContentValues();
		String[] cols = {"name","weight","age","alive","health","alarm"};
		Cursor cursor = database.query(Database.TABLE_SHEEP, cols, "id="+id, null, null, null, null);
		cursor.moveToFirst();
		for(int i = 0; i < cursor.getColumnCount(); i++){
			if(cursor.getString(i) != null)
				values.put(cursor.getColumnName(i), cursor.getString(i));
			else{
				values.put(cursor.getColumnName(i), "");
				values.putNull(cursor.getColumnName(i));
			}
		}
		cursor.close();
		return values;
	}

	/**
	 * Henter en saus posisjon og navn
	 * @param id  Sauens id
	 * @return position
	 */
	public ContentValues getSheepPositionFromDatabase(int id){
		ContentValues position = new ContentValues();
		String[] pos = {"longitude", "latitude","name"};
		Cursor cursor = database.query(Database.TABLE_SHEEP, pos, "id="+id, null, null, null, "name");
		cursor.moveToFirst();
		for(int j = 0; j < cursor.getColumnCount(); j++){
			position.put(cursor.getColumnName(j), cursor.getString(j));

		}
		cursor.close();

		return position;
	}

	/**
	 * Henter sauens status (om den er levende, død eller har alarm)
	 * @param id Sauens id
	 * @return status
	 */
	public ContentValues getSheepStatusFromDatabase(int id) {
		ContentValues status = new ContentValues();
		String[] stat = {"alive", "alarm"};
		Cursor cursor = database.query(Database.TABLE_SHEEP, stat, "id="+id, null, null, null, "name");
		cursor.moveToFirst();
		for (int i = 0; i < cursor.getColumnCount(); i++) {
			status.put(cursor.getColumnName(i), cursor.getString(i));
		}
		cursor.close();
		return status;
	}

	/**
	 * Henter alle saueid-ene som ligger i den lokale databasen
	 * @return idlist
	 */
	public ArrayList<Integer> getSheepIdFromDatabase(){
		ArrayList<Integer> idlist = new ArrayList<Integer>();
		String[] names = {"id"};
		Cursor cursor = database.query(Database.TABLE_SHEEP, names, null, null, null, null, "name");
		cursor.moveToFirst();
		for(int i = 0; i < cursor.getCount(); i++){
			idlist.add(cursor.getInt(0));
			cursor.moveToNext();
		}
		cursor.close();
		return idlist;
	}

	/**
	 * Henter navn på alle sauer som ligger i den lokale databasen
	 * @return namelist
	 */
	public ArrayList<String> getSheepNamesFromDatabase(){
		ArrayList<String> namelist = new ArrayList<String>();
		String[] names = {"name"};
		Cursor cursor = database.query(Database.TABLE_SHEEP, names, null, null, null, null, "name");
		cursor.moveToFirst();
		for(int i = 0; i < cursor.getCount(); i++){
			namelist.add(cursor.getString(0));
			cursor.moveToNext();
		}
		cursor.close();
		return namelist;
	}

}  