package com.g19.find_my_sheep;


import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;

import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

/**
 * @author Fredrik Tørnvall
 * @author Said Turusbekov
 *
 * Klasse som gir mulighet for å registrere en brukerprofil
 */
public class RegUser extends Activity {
	TextView tv;
	ProgressDialog progress;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_reg_user);

		Button reg = (Button) findViewById(R.id.b3Reg);
		tv = (TextView) findViewById(R.id.tvLog);

		reg.setOnClickListener(new View.OnClickListener() {
			/** Starter brukerregistreringsprosessen i en ny tråd */
			@Override
			public void onClick(View arg0) {
				if(isNetworkAvailable()){
					progress = new ProgressDialog(RegUser.this, AlertDialog.THEME_HOLO_DARK);
					progress.setTitle("Vent");
					progress.setMessage("Lagrer bruker...");
					progress.show();
					new regAction().execute();
				}else
					Toast.makeText(RegUser.this, "Ingen nettverkstilkobling", Toast.LENGTH_SHORT).show();
			}
		});
	}

	/** @see MainActivity#isNetworkAvailable() */
	private boolean isNetworkAvailable() {
		ConnectivityManager connectivityManager 
		= (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
		NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
		return activeNetworkInfo != null && activeNetworkInfo.isConnected();
	}

	/** 
	 * Trådklasse som håndterer brukerregistreringsprosessen. 
	 * Avslutter aktiviteten og bruker registreres i databasen dersom serverrespons er OK
	 */
	private class regAction extends AsyncTask<Void,Void,String>{

		@Override
		protected void onPostExecute(String result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);

			TextView display = (TextView) findViewById(R.id.tvLog);
			//display.setText(Integer.toString(result));
			if(result.equals("correct")){
				new Handler().postDelayed(new Runnable() {
					@Override
					public void run() {
						Intent intent = new Intent(RegUser.this, MainActivity.class);
						startActivity(intent);
						finish();
					}
				}, 3000);
			} else {
				display.setText(result);
			}
			progress.dismiss();
		}

		@Override
		protected String doInBackground(Void... params) {
			// TODO Auto-generated method stub
			return reg();

		}

		/**
		 * Metode som validerer input i tekstfeltene
		 * @param inputName
		 * @param inputEmail
		 * @param inputUserName
		 * @param inputPassword
		 * @param inputPhone
		 * @return Melding   Eventuell feilmelding
		 */
		public String validate(String inputName, String inputEmail, String inputUserName, String inputPassword, String inputPhone){

			if (inputName.isEmpty() || inputEmail.isEmpty() || inputUserName.isEmpty() || inputPassword.isEmpty() || inputPhone.isEmpty()){
				return  "Ikke alle feltene ble utfult";
			}
			if (!inputName.matches("^[a-zA-Z]+$")){ 
				return "Feil i Navnet";	
			}

			if (!inputEmail.matches("^[_A-Za-z0-9-]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$")){
				return "Feil i emailen!";
			}

			if (!inputUserName.matches("^[a-zA-Z0-9]+$")){
				return "Feil i brukernavnet";
			}

			if (!inputPassword.matches("^[a-zA-Z0-9]+$")){
				return "Feil i Passordet";
			}

			if (!inputPhone.matches("^[0-9]+$")){
				return "Feil i telefonnummeret";
			}

			return "riktig";
		}

		
		/**
		 * Sender brukerinformasjon til server og sjekker om bruker allerede finnes eller lagrer informasjon
		 * @return melding
		 */
		private String reg(){

			HttpClient httpclient = new DefaultHttpClient();
			HttpPost httppost = new HttpPost("http://129.241.126.66/cgi-bin/adduser.py");

			final EditText name = (EditText) findViewById(R.id.etName);
			final EditText email = (EditText) findViewById(R.id.etEmail);
			final EditText username = (EditText) findViewById(R.id.etUser);
			final EditText password = (EditText) findViewById(R.id.etPassword);
			final EditText telephone = (EditText) findViewById(R.id.etTlf);
			final EditText backup = (EditText) findViewById(R.id.etBack);

			String nameString = name.getText().toString();
			String emailString = email.getText().toString();
			String usernameString = username.getText().toString();
			String passwordString = password.getText().toString();
			String telephoneString = telephone.getText().toString();
			String backupString = backup.getText().toString(); //Trenger en valideringsmetode p� denne!!

			if(!validate(nameString,emailString, usernameString, passwordString, 
					telephoneString).equals("riktig")) {
				return (validate(nameString, emailString, usernameString, 
						passwordString, telephoneString));
			}

			/* Sender brukerinformasjon som parametere til scriptet adduser.py som sjekker om bruker eksisterer og evt lagrer bruker */
			try {
				// Add your data
				List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(6);
				nameValuePairs.add(new BasicNameValuePair("name", nameString));
				nameValuePairs.add(new BasicNameValuePair("email", emailString));
				nameValuePairs.add(new BasicNameValuePair("username", usernameString));
				nameValuePairs.add(new BasicNameValuePair("password", passwordString));
				nameValuePairs.add(new BasicNameValuePair("tlf", telephoneString));
				nameValuePairs.add(new BasicNameValuePair("backup", backupString));

				httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));

				// Execute HTTP Post Request
				HttpResponse response = httpclient.execute(httppost);
				if(response.getStatusLine().getStatusCode() == 200){
					return "correct";
				}

			} catch (ClientProtocolException e) {
				// TODO Auto-generated catch block
			} catch (IOException e) {
				// TODO Auto-generated catch block
			} catch(Exception e){
				e.printStackTrace();
			}
			return "wrong";
		}
	}
}

