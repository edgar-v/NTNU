#!/usr/bin/python

import psycopg2
import cgi
import sys

#for debugging
import cgitb
cgitb.enable()

# Establish a connection to the database
conn = psycopg2.connect("dbname=findmysheep user=postgres host=localhost password=kohxooto")

# Fetch parameters from the request
form = cgi.FieldStorage()

try:
    username = form['username'].value
    gcmid = form['gcmid'].value
except KeyError, e:
    print '''Status: 400
Content-type: text/html

'''
    print("missing argument")
    print e
    sys.exit()

cur = conn.cursor()

cur.execute("UPDATE users SET gcm = '%s' WHERE username = '%s';" % (gcmid, username))

# Commit the changes we have made to the database
conn.commit()

# Close the connection
cur.close()
conn.close()

# Return an OK status message
print '''Status: 200
Content-type: text/html

'''

