#!/usr/bin/python

import psycopg2
import hashlib
import sys
import cgi
import json
from datetime import date
import datetime
from time import mktime

#For debugging
import cgitb
cgitb.enable()

# Establish a connection
connection = psycopg2.connect("dbname=findmysheep user=postgres host=localhost password=kohxooto")

# Open a transaction
cursor = connection.cursor()

# Get the parameters from the request
formdata = cgi.FieldStorage()

# See if all the params are present, if not return an error message and exit
try:
    username = formdata['username'].value
    password = formdata['password'].value
    gcm = formdata['gcm'].value
except KeyError:
    print '''Status: 400
Content-type: text/html

'''
    sys.exit() 
cursor.execute("UPDATE users SET gcm = '%s' WHERE username = '%s';" % (gcm, username))
cursor.execute("SELECT * FROM users WHERE username = '%s';" % username)

# If no such user exists, return an error and exit
userinfo = cursor.fetchone()
if userinfo == None:
    print '''Status: 404
Content-type: text/html

'''
    sys.exit()

# Read the information sent back by the request
original_password = userinfo[5]
salt = userinfo[6]

# Hash the password that was passed to us from the user together with the salt from the database
password_hash = hashlib.sha1(bytes(password + salt)).hexdigest()

# If the hashed password matches the hashed password in the database, return OK
if password_hash != original_password:
    print "Status: 200\r\nContent-type: text/html\r\n\r\n"

cursor.execute("SELECT * FROM sheep WHERE bonde = %s ORDER BY id;" % userinfo[0])
sheep = cursor.fetchall()


response = "Status: 200\r\nContent-type: application/json\r\n\r\n"
userjson = {'username':userinfo[1], 'name':userinfo[2], 'email':userinfo[3], 'tlf':userinfo[4], 'secondary_email':userinfo[8], 'gcm':userinfo[9]}

sheepjson = []
for s in sheep:
    sheepdict = {'id':s[0],'longitude':s[1], 'latitude':s[2], 'name':s[3], 'age':str(s[4]), 'weight':s[5], 'alive':s[6], 'alarm':s[7], 'comment':s[9]}
    sheepjson.append(sheepdict) 

cursor.execute("SELECT * from log WHERE farmer = %s;" % userinfo[0])

log = cursor.fetchall()

logjson = []
for l in log:
    logdict = {'sheep': l[2], 'timestamp':str(l[3] + datetime.timedelta(hours=1)).split('.')[0], 'alive':l[4], 'alarm':l[5], 'longitude':l[6], 'latitude':l[7]}
    logjson.append(logdict)

jsondata = { "user" : userjson, "sheep" : sheepjson, "log" : logjson }
jsondata = json.dumps(jsondata)
response += jsondata
print(response)

# Close the transaction and connection
connection.commit()
cursor.close()
connection.close()
