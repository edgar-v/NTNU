#!/usr/bin/python

import psycopg2
import hashlib
import random
import cgi
import sys

# Establish a connection to the database
conn = psycopg2.connect("dbname=findmysheep user=postgres host=localhost password=kohxooto")

# Fetch parameters from the request
form = cgi.FieldStorage()

# See if the parameters were sent
try:
    sheepid = form['sheepid'].value
    age = form['age'].value
    weight = form['weight'].value
    name = form['name'].value
    comment = form['comment'].value
    cur = conn.cursor()
except KeyError:
    print '''Status: 400
Content-type: text/html

'''
    sys.exit()

try:
    # Insert the user into the database
    cur.execute("UPDATE sheep SET name='%s', age='%s', weight='%s', comment='%s' WHERE id=%s;" % (name, age, weight, comment, sheepid))

except Exception, e:
    # If the transaction fails return an error and exit.
    # This will happen if the user already exists in the database
    print '''Status: 420
Content-type: text/html

'''
    print e
    sys.exit()

# Commit the changes we have made to the database
conn.commit()

# Close the connection
cur.close()
conn.close()

# Return an OK status message
print '''Status: 200
Content-type: text/html

'''

