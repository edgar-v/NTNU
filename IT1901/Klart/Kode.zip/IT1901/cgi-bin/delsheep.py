#!/usr/bin/python

import psycopg2
import hashlib
import random
import cgi
import sys

#for debugging
import cgitb
cgitb.enable()

# Establish a connection to our database
conn = psycopg2.connect("dbname=findmysheep user=postgres host=localhost password=kohxooto")

# Fetch the parameters from the request
form = cgi.FieldStorage()
# Check if all the required parameters are sent
try:
    sheepid = form['sheepid'].value
    cur = conn.cursor()
except KeyError:
    # Return an error message if a parameter is missing
    print '''Status: 400
Content-type: text/html

'''        
    sys.exit()

# Insert a new sheep into the database with a relation to the farmer
try:
    cur.execute("DELETE FROM sheep WHERE id = '%s';" %  sheepid)
except:
    print '''Status: 420
Content-type: text/html

'''

# Commit the changes and close the transaction and database
conn.commit()
cur.close()
conn.close()

# Return OK
print "Status: 200"
print '''Content-type: text/html

'''
